﻿	--@wither2x You little F**ker You made a shit of piece with your trash code
	tbom = RegisterMod("The Binding of Madou",1)

	local teammeat10 = Font()
	teammeat10:Load("font/teammeatfont10.fnt")
	local teammeatExtended10 = Font()
	teammeatExtended10:Load("font/teammeatfontextended10.fnt")
	local lanapixel = Font()
	lanapixel:Load("font/cjk/lanapixel.fnt")
	local terminus8 = Font()
	terminus8:Load("font/terminus8.fnt")
	local pftempesta7 = Font()
	pftempesta7:Load("font/pftempestasevencondensed.fnt")
	local mplus_12b = Font()
	mplus_12b:Load("font/mplus_12b.fnt")
	local upheavalextended = Font()
	upheavalextended:Load("font/upheavalextended.fnt")

	local FontList = {
		en = pftempesta7,
		zh = lanapixel,
	}

	local ItemID = {
		bluegrimoire = Isaac.GetItemIdByName("Blue Grimoire"),
		greengrimoire = Isaac.GetItemIdByName("Green Grimoire"),
	}

	local SoundID = {
		expget = Isaac.GetSoundIdByName("EXP Get"),
		lasersight = Isaac.GetSoundIdByName("Laser Sight"),
		lockonmark = Isaac.GetSoundIdByName("Lock-on Mark"),
		gelget = Isaac.GetSoundIdByName("Gel Get"),
		puyoowanimo = Isaac.GetSoundIdByName("Puyo Owanimo"),
		puyobrust = Isaac.GetSoundIdByName("Puyo Brust"),
	}
		------v0.0.3改动------
	local modEffectVariant = {
		EXP = Isaac.GetEntityVariantByName("EXP"),
		LASERSIGHT = Isaac.GetEntityVariantByName("Laser Sight"),
		LOCKONMARK = Isaac.GetEntityVariantByName("Lock-on Mark"),
		MAGIC_CIRCLE = Isaac.GetEntityVariantByName("Magic Circle"),
		PUYO_GIBS = Isaac.GetEntityVariantByName("Puyo Gibs"),
		----------------------
		GRANDCROSS_MISSLE = Isaac.GetEntityVariantByName("Grand Cross Missle"),
		GRANDCROSS_AIRCRAFT = Isaac.GetEntityVariantByName("Grand Cross Aircfraft"),
		GRANDCROSS_FILTER = Isaac.GetEntityVariantByName("Grand Cross Filter"),

		BLANK_ANIM = Isaac.GetEntityVariantByName("Blank Animation"),
		PUYO_FIRE_POINT = Isaac.GetEntityVariantByName("Puyo Fire Point"),
	}

	local modPickupVariant = {
		PICKUP_MANA = Isaac.GetEntityVariantByName("Mana"),
		PICKUP_GEL = Isaac.GetEntityVariantByName("Green Gel"),
	}

	local GelSubType = {
		GEL_GREEN = 0,
	}

	local modFamiliarVariant = {
		LIGHT_ORB = Isaac.GetEntityVariantByName("Light Orb"),
	}

	------v0.1.0新增
	local ChallengeID = {
		CHALLENGE_METEOR_SHOWER = Isaac.GetChallengeIdByName("Meteor Shower"),
	}
	------

	local modEntityType = {
		PUYO = EntityType.ENTITY_MINISTRO,
	}

	local PuyoVariant = {
		GREEN_PUYO = Isaac.GetEntityVariantByName("Green Puyo"),
	}

	tbom.ItemID = ItemID

	--判断变量是否在table中，返回真或假
		function isInTable(v, table)
			for _, v_table in pairs(table) do
				if v == v_table then
					return true
				end
			end
			return false
		end

	--检查角色射击方向，返回向量
		function ShootDirection(shoot_dir)
			if shoot_dir ~= Direction.NO_DIRECTION then
				if shoot_dir == Direction.UP then
					return Vector(0, -1)
				elseif shoot_dir == Direction.DOWN then
					return Vector(0, 1)
				elseif shoot_dir == Direction.LEFT then
					return Vector(-1, 0)
				elseif shoot_dir == Direction.RIGHT then
					return Vector(1, 0)
				end
			end
			return Vector.Zero
		end

	--判断item是否为不占被动槽位的道具（主动道具、任务道具、长子权），返回真或假
		function IsNoPassiveSlotItem(item)
			if item == CollectibleType.COLLECTIBLE_BIRTHRIGHT then
				return true
			end
			local item_config = Isaac.GetItemConfig():GetCollectible(item)
			if (item_config) then
				if (item_config.Type == ItemType.ITEM_ACTIVE or item_config:HasTags(ItemConfig.TAG_QUEST)) then
					return true
				end
			end
			return false
		end

	--统计所有道具，返回表
		function GetAllSlotItem()
			local ItemList = {}
			for i = 1, Isaac.GetItemConfig():GetCollectibles().Size do
				if (Isaac.GetItemConfig():GetCollectible(i)) then	--此处条件不可忽略，否则当i的ItemConfig值为nil时会报错
					table.insert(ItemList, i)
				end
			end
			return ItemList
		end

	--统计所有不占被动槽位的道具，返回表
		function GetNoPassiveSlotItem()
			local ItemList = {}
			for i = 1, Isaac.GetItemConfig():GetCollectibles().Size do
				if IsNoPassiveSlotItem(i) then
					table.insert(ItemList, i)
				end
			end
			return ItemList
		end

	--统计所有品质为quality的道具，返回表（过滤隐藏道具和任务道具）
		function GetAllItem_ByQuality(quality)
			local ItemList = {}
			for i = 1, Isaac.GetItemConfig():GetCollectibles().Size do
				if (Isaac.GetItemConfig():GetCollectible(i)) then
					if Isaac.GetItemConfig():GetCollectible(i).Quality == quality and (not Isaac.GetItemConfig():GetCollectible(i).Hidden) and (not Isaac.GetItemConfig():GetCollectible(i):HasTags(ItemConfig.TAG_QUEST)) then
						table.insert(ItemList, i)
					end
				end
			end
			return ItemList
		end

	--强制添加道具，如果角色（里以撒）道具槽位已满，则在角色身边生成道具，无返回值
		local NoPassiveSlotItem

		function AddCollectibleForcibly(player, item)
			local canAddCollectible = true
			if player:GetPlayerType() == PlayerType.PLAYER_ISAAC_B then
				local slot_capacity
				if player:HasCollectible(CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
					slot_capacity = 12
				else
					slot_capacity = 8
				end
				local slot_remain = slot_capacity - player:GetCollectibleCount()
				NoPassiveSlotItem = NoPassiveSlotItem or GetNoPassiveSlotItem()
				for i, j in pairs(NoPassiveSlotItem) do
					slot_remain = slot_remain + player:GetCollectibleNum(j)
				end
				if slot_remain <= 0 then
					canAddCollectible = false
				end
			end
			if canAddCollectible then
				player:AddCollectible(item)
			else
				Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_COLLECTIBLE, item, Game():GetRoom():FindFreePickupSpawnPosition(player.Position, 0, true), Vector.Zero, nil)
			end
			return
		end

	--四舍五入保留小数点后m位，返回浮点数
		function Fix_Round(x, m)
			local mod = 10 ^ m
			return math.floor(x * mod + 0.5) / mod
		end


	--计算一个二阶方阵matrix的行列式，返回浮点数
		function Determinant_2x2(matrix)
			local det = matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1]
			return det
		end

	--计算一个三阶方阵matrix的行列式，返回浮点数
		function Determinant_3x3(matrix)
			local det = matrix[1][1] * matrix[2][2] * matrix[3][3] 
				+ matrix[1][2] * matrix[2][3] * matrix[3][1] 
				+ matrix[1][3] * matrix[2][1] * matrix[3][2] 
				- matrix[1][3] * matrix[2][2] * matrix[3][1] 
				- matrix[1][2] * matrix[2][1] * matrix[3][3] 
				- matrix[1][1] * matrix[2][3] * matrix[3][2]
			return det
		end
		
	--计算一个N*M矩阵matrix的秩，返回整数
		function Rank_NxM(matrix, N, M)
			local rank = 0
			local row = 1
			local k = 1
			local temp
			for i = 1, M do
				k = row
				for j = row + 1, N do
					if math.abs(matrix[k][i]) < math.abs(matrix[j][i]) then
						k = j
					end
				end
				if k ~= row then
					for j = i, M do
						temp = matrix[row][j]
						matrix[row][j] = matrix[k][j]
						matrix[k][j] = temp
					end
				end
				if matrix[row][i] == 0 then
					goto Rank_continue
				else
					rank = rank + 1
					for j = 1, N do
						if j ~= row then
							temp = (-1) * matrix[j][i] / matrix[row][i]
							for k = i, M do
								matrix[j][k] = matrix[j][k] + temp * matrix[row][k]
							end
						end
					end
					temp = matrix[row][i]
					for j = i, M do
						matrix[row][j] = matrix[row][j] / temp
					end
				end
				row = row + 1
				if row > N then
					break
				end
				::Rank_continue::
			end
			return rank
		end

	--计算自然数n的阶乘，返回整数
		function maths_Fact(n)
			if n == 0 then
				return 1
			elseif n > 0 then
				return n * maths_Fact(n - 1)
			elseif n < 0 then
				return nil
			end
		end

	--计算从n个不同元素中任取m个元素的排列数，返回整数
		function maths_Perm(m, n)
			if n >= m then
				return (maths_Fact(n) / maths_Fact(n - m))
			else
				return 0
			end
		end

	--计算从n个不同元素中任取m个元素的组合数，返回整数
		function maths_Comb(m, n)
			return (maths_Perm(m, n) / maths_Fact(m))
		end

	local ItemList_All

	--统计角色拥有的、品质为quality的道具数目，返回整数
		function GetCollectibleNum_ByQuality(player, quality)
			local sum = 0
			ItemList_All = ItemList_All or GetAllSlotItem()
			for i, item in pairs(ItemList_All) do
				if Isaac.GetItemConfig():GetCollectible(item).Quality == quality then
					sum = sum + player:GetCollectibleNum(item)
				end
			end
			return sum
		end

	--统计角色拥有的、带有标签tag的道具数目，返回整数
		function GetCollectibleNum_ByTags(player, tag)
			local sum = 0
			ItemList_All = ItemList_All or GetAllSlotItem()
			for i, item in pairs(ItemList_All) do
			--for i = 1, Isaac.GetItemConfig():GetCollectibles().Size do
				if Isaac.GetItemConfig():GetCollectible(item):HasTags(tag) then
					sum = sum + player:GetCollectibleNum(item)
				end
			end
			return sum
		end

	--随机生成一个品质为quality的道具，无返回值
		function RandomCollectible_ByQuality(player, quality)
			local ItemList_ByQuality = ItemList_ByQuality or GetAllItem_ByQuality(quality)
			local size = #ItemList_ByQuality
			local num = math.random(1, size)
			local ti = 0
			local item = ItemList_ByQuality[num]
			while player:HasCollectible(item) and ti < size do
				num = num + 1
				ti = ti + 1
				item = ItemList_ByQuality[num]
			end
			if ti == size then
				if quality == 0 then
					item = 36
				elseif quality == 1 then
					item = 22
				elseif quality == 2 then
					item = 73
				elseif quality == 3 then
					item = 50
				elseif quality == 4 then
					item = 118
				end
			end

			Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_COLLECTIBLE, item, Game():GetRoom():FindFreePickupSpawnPosition(player.Position, 0, true), Vector.Zero, nil)
		end

	--由等级计算所需经验值，返回浮点数
		function Reberu2EXP(Reberu)
			local EXP = 0
			if Reberu > 0 then
				if Reberu <= 16 then
					EXP = Reberu ^ 2 + Reberu * 6
				elseif Reberu <= 31 then
					EXP = (Reberu ^ 2) * 2.5 - Reberu * 40.5 + 360
				else
					EXP = (Reberu ^ 2) * 4.5 - Reberu * 162.5 + 2220
				end
			else
				EXP = 0
			end
			return EXP
		end

	--由经验值计算对应等级，返回整数
		function EXP2Reberu(EXP)
			local Reberu = 0
			if EXP > 0 then
				if EXP <= 390 then
					Reberu = math.sqrt(EXP + 9) - 3
				elseif EXP <= 1623 then
					Reberu = (math.sqrt(40 * EXP - 7839) + 81) / 10
				else
					Reberu = (math.sqrt(72 * EXP - 54215) + 325) / 18
				end
			else
				Reberu = 0
			end
			return math.floor(Reberu)
		end

	--逻辑异或
		function Xor(a,b)
			return ((not a) and b) or (a and (not b))
		end

	--播放某实体的特殊动画，返回“空白动画”效果实体
		function PlayUniqueAnimation(entity, anim_name)
			local sprite = entity:GetSprite()
			local FILE = sprite:GetFilename()
			local effect = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.BLANK_ANIM, 0, entity.Position, Vector.Zero, entity)
			local effect_sprite = effect:GetSprite()
			effect_sprite:Load(FILE, true)
			effect_sprite:Play(anim_name)
			return effect
		end

	--MOD角色
		local arlePlayerType = Isaac.GetPlayerTypeByName("Arle Nadja",false)
		local arleBPlayerType = Isaac.GetPlayerTypeByName("Tainted Arle",true)
		local doppelPlayerType = Isaac.GetPlayerTypeByName("Doppelganger Arle",false)

		local arleCostume = Isaac.GetCostumeIdByPath("gfx/characters/character_arle_hair.anm2")
		local doppelCostume = Isaac.GetCostumeIdByPath("gfx/characters/character_doppel_hair.anm2")

		tbom.modPlayerType = {
			ArleNadja = arlePlayerType,
			Arle_B = arlePlayerType_B,
			DoppelgangerArle = doppelPlayerType,
		}

		local arleData_DEFAULT = {		--//
			EXP = 0,			--经验值
			Reberu = 0,			--等级
			ReberuCount = 0,	--升级提示语计数
			CacheFlags = {},	--升级奖励缓存标记
			FlashShootBonus = 1,--表形态清图奖励倍率
			MomKilled = false,
			MomsHeartKilled = false,
		}

		local MagicName = {
			FIRE = 1,
			ICE = 2,
			THUNDER = 3,
			HEALING = 4,
			DIACUTE = 5,
			BAYOEN = 6,
			BARRIER = 7,
			JUGEM =  8,
			LWARKWOID = 9,
			DARKSLASH = 10,
			GRANDCROSS = 11,
		}

		local MagicType = {
			AGGRESSIVE = 1,		--攻击性法术：无CD，使用期间每秒消耗魔导力
			DEFENSIVE = 2,		--防御性法术：有CD，使用瞬间消耗魔导力，CD期间不可使用
			SPECIAL = 3,		--特殊法术：有CD，使用瞬间消耗魔导力，CD期间某段时间内仍可使用
			LOCKON = 4,			--瞄准-锁定型法术：无专用CD，使用后每瞄准一个目标消耗魔导力
		}

		------v0.0.3改动：对两个magic_data均有效
		local magic_data_DEFAULT = {		--//
			PlayerData = {
				MadouRyoku = 5,										--魔导力
				MadouJyougen = 20,									--魔导力上限
				MagicAttribute = "Void",							--魔法属性（光Light、暗Dark、影Shadow、间Void）
				CurrentMagicKey = 1,								--当前法术序号
				UseableMagic = {1,2,3,4,5,6,7,8},					--可用法术列表，用于阿露露
				UseableVoidMagic = {[1] = 0, [2] = 0, [3] = 0,},	--可用间属性法术列表，用于其他角色
				UsingAggressiveMagic = false,						--是否正在使用攻击性法术，用于阿露露
				UsedAggressiveMagic = false,						--当前房间是否用过全屏杀伤性法术（3级或3级以上的火炎术或冰霜风暴）
				HasBarrier = 0,										--神圣屏障层数
				MagicCircle = nil,									--法阵实体
				LaserSight = nil,									--锁定光束实体
				LockonTargetHeap = {},								--锁定目标堆,用于模拟链表结构
				LockonCount = 0,									--瞄准目标后的短暂冷却时间计数器
				LockonDMGMulti = 1,									--引爆时的伤害倍率，与法术本身有关，也受二阶强化术影响
				TearFlagSeed = 0,									--随机整数，决定每颗子弹是否具有特效
				SelfFireDelay = 0,									--角色自身射击延迟
				FamiliarFireDelay = 0,								--跟班射击延迟，用于模拟角色射击及兼容饰品
				VoidCount = 0,										--魔导书被在虚空吃掉的情况下，单房间内的使用次数，用于兼容虚空
			},
			Magic = {
				[MagicName.FIRE] = {
					Name = {						--法术名称
						["Light"] = {en = "Fire",zh = "火炎术",},
						["Dark"] = {en = "Abyss",zh = "狱炎术",},
						["Shadow"] = {en = "Flame Tornado",zh = "卷炎术",},
					},
					CD = 0,							--恢复时间，对于没有CD的法术，若CD等于1则为正在使用中，每秒消耗魔导力；否则为未使用，不消耗魔导力
					Cost = 0.2,						--每秒耗蓝量
					CostCP = 0,						--时钟脉冲，用于耗蓝计时，等于0时耗一次蓝
					CostDesc = {					--耗蓝量具体说明
						en = "0.2 points per second",
						zh = "每秒0.2点",
					},
					Reberu = 1,						--法术等级，大于0时即视为已解锁该法术
					Type = MagicType.AGGRESSIVE,	--法术类型
					IconPos = Vector(0,0),			--图标位置
				},
				[MagicName.ICE] = {
					Name = {
						["Light"] = {en = "Ice Storm",zh = "冰霜风暴",},
						["Dark"] = {en = "Chaos",zh = "混沌冰暴",},
						["Shadow"] = {en = "Dark Blizzard",zh = "暗夜霜暴",},
						["Void"] = {en = "Ice", zh = "冰冻术",},
					},
					CD = 0,
					Cost = 0.2,
					CostCP = 0,
					CostDesc = {
						en = "0.2 points per second",
						zh = "每秒0.2点",
					},
					Reberu = 1,
					Type = MagicType.AGGRESSIVE,
					IconPos = Vector(0,0),
				},
				[MagicName.THUNDER] = {
					Name = {
						["Light"] = {en = "Thunder",zh = "闪电术",},
						--["Dark"] = {en = "Lighting",zh = "雷电术",},
						["Shadow"] = {en = "Heavenly Thunder",zh = "裂天震电",},
					},
					CD = 0,
					Cost = 0.3,
					CostCP = 0,
					CostDesc = {
						en = "0.3 points per second",
						zh = "每秒0.3点",
					},
					Reberu = 0,
					Type = MagicType.AGGRESSIVE,
					IconPos = Vector(0,0),
				},
				[MagicName.HEALING] = {
					Name = {
						["Light"] = {en = "Healing",zh = "治疗术",},
					},
					CD = {
						STD = 80 * 60,	--标准恢复时间（常量）
						Current = 0,	--当前剩余恢复时间（变量）
					},
					Cost = 25,
					Reberu = 0,
					Type = MagicType.DEFENSIVE,
					IconPos = Vector(0,0),
				},
				[MagicName.DIACUTE] = {
					Name = {
						["Light"] = {en = "Diacute",zh = "二阶强化术",},
						["Dark"] = {en = "Labyrinth",zh = "幻惑强化术",},
					},
					CD = {
						STD = 60 * 60,
						Current = 0,
					},
					Cost = 15,
					OrbsCount = 0,		--光球数量
					Reberu = 0,
					Type = MagicType.SPECIAL,
					IconPos = Vector(0,0),
				},
				[MagicName.BAYOEN] = {
					Name = {
						["Light"] = {en = "Bayoen",zh = "繁花乱象",},
						["Dark"] = {en = "Ragnarok",zh = "末世幻象",},
					},
					CD = {
						STD = 100 * 60,
						Current = 0,
					},
					Cost = 25,
					Reberu = 0,
					Type = MagicType.DEFENSIVE,
					IconPos = Vector(0,0),
				},
				[MagicName.BARRIER] = {
					Name = {
						["Light"] = {en = "Revia",zh = "荆棘障壁",},
						["Dark"] = {en = "Void Hole",zh = "虚空虹洞",},
						["Void"] = {en = "Barrier", zh = "屏障术",},
					},
					CD = {
						STD = 60 * 60,
						Current = 0,
					},
					Cost = 20,
					Reberu = 0,
					Type = MagicType.DEFENSIVE,
					IconPos = Vector(0,0),
				},
				[MagicName.JUGEM] = {
					Name = {
						["Light"] = {en = "Jugem",zh = "气爆弹",},
					},
					CD = 0,
					Cost = 5,
					CostCP = 0,			--瞄准目标数量（静态变量）
					TargetAmount = 4,	--目标数量上限（常量）
					CostDesc = {
						en = "5 points per target",
						zh = "每个目标5点",
					},
					Reberu = 0,
					Type = MagicType.LOCKON,
					------v0.0.1改动------
					DMGMulti = 20,		--该法术专用的伤害倍率（常量）
					------
					IconPos = Vector(0,0),
				},
				[MagicName.LWARKWOID] = {
					Name = {
						["Light"] = {en = "",zh = "",},
						["LightB"] = {en = "Lwark Woid",zh = "吸星术",},
					},
					CD = {
						STD = 1 * 60,
						Current = 0,
					},
					Cost = 0,
					Reberu = 0,
					Type = MagicType.DEFENSIVE,
					IconPos = Vector(0,0),
				},
				[MagicName.DARKSLASH] = {
					Name = {
						["Light"] = {en = "",zh = "",},
						["Dark"] = {en = "Dark Slash",zh = "暗黑裂隙",},
					},
					CD = 0,
					Cost = 2,
					CostCP = 0,
					TargetAmount = 6,
					CostDesc = {
						en = "2 points per target",
						zh = "每个目标2点",
					},
					--测试用
					Reberu = 1,
					--
					Type = MagicType.LOCKON,
					DMGMulti = 1.5,
					IconPos = Vector(0,0),
				},
				[MagicName.GRANDCROSS] = {
					Name = {
						["Light"] = {en = "",zh = "",},
						["Dark"] = {en = "Grand Cross",zh = "灾星阵",},
					},
					--测试用
					CD = {
						STD = 3 * 60,
						Current = 0,
					},
					Cost = 10,
					Reberu = 1,
					----
					Type = MagicType.DEFENSIVE,
					IconPos = Vector(0,0),
				},
			},
		}

		function canUseVariousSpells(player)
			local playerType = player:GetPlayerType()
			return playerType == arlePlayerType or playerType == doppelPlayerType
		end

		function canGetEXP(player)
			local playerType = player:GetPlayerType()
			return playerType == arlePlayerType or playerType == doppelPlayerType
		end

		function GetMageCharacterNum()
			local sum = 0
			for i = 0, Game():GetNumPlayers() - 1 do
				local player = Isaac.GetPlayer(i)
				if canUseVariousSpells(player) then
					sum = sum + 1
				end
			end
			return sum
		end

		function GetEXPCharacterNum()
			local sum = 0
			for i = 0, Game():GetNumPlayers() - 1 do
				local player = Isaac.GetPlayer(i)
				if canGetEXP(player) then
					sum = sum + 1
				end
			end
			return sum
		end

		function tbom:CharacterInit(player)
			local game = Game()
			if player and player.Variant == 0 then
				local playerType = player:GetPlayerType()
				if playerType == arlePlayerType then
					player:TryRemoveNullCostume(arleCostume)
					player:AddNullCostume(arleCostume)
					
					if (not (game:GetRoom():GetFrameCount() < 0 and game:GetFrameCount() > 0)) then
						player:SetPocketActiveItem(ItemID.bluegrimoire, ActiveSlot.SLOT_POCKET, false)
					end
				elseif playerType == doppelPlayerType then
					player:TryRemoveNullCostume(doppelCostume)
					player:AddNullCostume(doppelCostume)

					if (not (game:GetRoom():GetFrameCount() < 0 and game:GetFrameCount() > 0)) then
						player:SetPocketActiveItem(ItemID.bluegrimoire, ActiveSlot.SLOT_POCKET, false)
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, tbom.CharacterInit)

		------v0.1.0新增
		function tbom:CharacterInit_Challenge(player)
			if player and player.Variant == 0 then
				if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER then
					player:ChangePlayerType(arlePlayerType)
				end
			end
		end
		tbom:AddPriorityCallback(ModCallbacks.MC_POST_PLAYER_INIT, CallbackPriority.EARLY, tbom.CharacterInit_Challenge)

		function tbom:Reset_Challenge(boolean_isContinued)
			if (not boolean_isContinued) then
				if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER then
					local player = Isaac.GetPlayer(0)
					local pool = Game():GetItemPool()
					player:AddCollectible(ItemID.greengrimoire)
					pool:RemoveCollectible(CollectibleType.COLLECTIBLE_HOST_HAT)
					pool:RemoveCollectible(CollectibleType.COLLECTIBLE_PYROMANIAC)
					pool:RemoveCollectible(CollectibleType.COLLECTIBLE_EPIC_FETUS)
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, tbom.Reset_Challenge)
		------

		function tbom:CharacterReset_old(boolean_isContinued)	--//可能会弃用此函数，改为每帧检查data中相关数据是否有效，如无效则设为默认值
			if not boolean_isContinued then
				for p = 0, Game():GetNumPlayers() - 1 do
					local player = Isaac.GetPlayer(p)
					local playerType = player:GetPlayerType()
					local data = player:GetData()
					--if canUseVariousSpells(player) then
						
					data.MagicData = GetDefaultMagicData()
						--magic_data.PlayerData.MadouRyoku = 20
						--magic_data.PlayerData.MadouJyougen = 20
						
						--arleData.EXP = 0
						--arleData.ReberuCount = 0
						--arleData.FlashShootBonus = 1
						--arleData.CacheFlags = {}
						--arleData.MomKilled = false
						--arleData.MomsHeartKilled = false
					--end
					if canGetEXP(player) then
						data.ArleData = GetDefaultArleData()
					end
					player:AddCacheFlags(CacheFlag.CACHE_ALL)
					player:EvaluateItems()
				end
			end
		end
		--tbom:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,tbom.CharacterReset_old)

		function tbom:CharacterReset(player)	--//
			local data = player:GetData()
			if data.MagicData == nil then
				data.MagicData = {		--//
					PlayerData = {
						MadouRyoku = 5,										--魔导力
						MadouJyougen = 20,									--魔导力上限
						MagicAttribute = "Void",							--魔法属性（光Light、暗Dark、影Shadow、间Void）
						CurrentMagicKey = 1,								--当前法术序号
						UseableMagic = {1,2,3,4,5,6,7,8},					--可用法术列表，用于阿露露
						UseableVoidMagic = {[1] = 0, [2] = 0, [3] = 0,},	--可用间属性法术列表，用于其他角色
						UsingAggressiveMagic = false,						--是否正在使用攻击性法术，用于阿露露
						UsedAggressiveMagic = false,						--当前房间是否用过全屏杀伤性法术（3级或3级以上的火炎术或冰霜风暴）
						HasBarrier = 0,										--神圣屏障层数
						MagicCircle = nil,									--法阵实体
						LaserSight = nil,									--锁定光束实体
						LockonTargetHeap = {},								--锁定目标堆,用于模拟链表结构
						LockonCount = 0,									--瞄准目标后的短暂冷却时间计数器
						LockonDMGMulti = 1,									--引爆时的伤害倍率，与法术本身有关，也受二阶强化术影响
						TearFlagSeed = 0,									--随机整数，决定每颗子弹是否具有特效
						SelfFireDelay = 0,									--角色自身射击延迟
						FamiliarFireDelay = 0,								--跟班射击延迟，用于模拟角色射击及兼容饰品
						VoidCount = 0,										--魔导书被在虚空吃掉的情况下，单房间内的使用次数，用于兼容虚空
					},
			end
			if data.ArleData == nil then
				data.ArleData = {		--//
					PlayerData = {
						MadouRyoku = 5,										--魔导力
						MadouJyougen = 20,									--魔导力上限
						MagicAttribute = "Void",							--魔法属性（光Light、暗Dark、影Shadow、间Void）
						CurrentMagicKey = 1,								--当前法术序号
						UseableMagic = {1,2,3,4,5,6,7,8},					--可用法术列表，用于阿露露
						UseableVoidMagic = {[1] = 0, [2] = 0, [3] = 0,},	--可用间属性法术列表，用于其他角色
						UsingAggressiveMagic = false,						--是否正在使用攻击性法术，用于阿露露
						UsedAggressiveMagic = false,						--当前房间是否用过全屏杀伤性法术（3级或3级以上的火炎术或冰霜风暴）
						HasBarrier = 0,										--神圣屏障层数
						MagicCircle = nil,									--法阵实体
						LaserSight = nil,									--锁定光束实体
						LockonTargetHeap = {},								--锁定目标堆,用于模拟链表结构
						LockonCount = 0,									--瞄准目标后的短暂冷却时间计数器
						LockonDMGMulti = 1,									--引爆时的伤害倍率，与法术本身有关，也受二阶强化术影响
						TearFlagSeed = 0,									--随机整数，决定每颗子弹是否具有特效
						SelfFireDelay = 0,									--角色自身射击延迟
						FamiliarFireDelay = 0,								--跟班射击延迟，用于模拟角色射击及兼容饰品
						VoidCount = 0,										--魔导书被在虚空吃掉的情况下，单房间内的使用次数，用于兼容虚空
					},
					Magic = {
						[MagicName.FIRE] = {
							Name = {						--法术名称
								["Light"] = {en = "Fire",zh = "火炎术",},
								["Dark"] = {en = "Abyss",zh = "狱炎术",},
								["Shadow"] = {en = "Flame Tornado",zh = "卷炎术",},
							},
							CD = 0,							--恢复时间，对于没有CD的法术，若CD等于1则为正在使用中，每秒消耗魔导力；否则为未使用，不消耗魔导力
							Cost = 0.2,						--每秒耗蓝量
							CostCP = 0,						--时钟脉冲，用于耗蓝计时，等于0时耗一次蓝
							CostDesc = {					--耗蓝量具体说明
								en = "0.2 points per second",
								zh = "每秒0.2点",
							},
							Reberu = 1,						--法术等级，大于0时即视为已解锁该法术
							Type = MagicType.AGGRESSIVE,	--法术类型
							IconPos = Vector(0,0),			--图标位置
						},
						[MagicName.ICE] = {
							Name = {
								["Light"] = {en = "Ice Storm",zh = "冰霜风暴",},
								["Dark"] = {en = "Chaos",zh = "混沌冰暴",},
								["Shadow"] = {en = "Dark Blizzard",zh = "暗夜霜暴",},
								["Void"] = {en = "Ice", zh = "冰冻术",},
							},
							CD = 0,
							Cost = 0.2,
							CostCP = 0,
							CostDesc = {
								en = "0.2 points per second",
								zh = "每秒0.2点",
							},
							Reberu = 1,
							Type = MagicType.AGGRESSIVE,
							IconPos = Vector(0,0),
						},
						[MagicName.THUNDER] = {
							Name = {
								["Light"] = {en = "Thunder",zh = "闪电术",},
								--["Dark"] = {en = "Lighting",zh = "雷电术",},
								["Shadow"] = {en = "Heavenly Thunder",zh = "裂天震电",},
							},
							CD = 0,
							Cost = 0.3,
							CostCP = 0,
							CostDesc = {
								en = "0.3 points per second",
								zh = "每秒0.3点",
							},
							Reberu = 0,
							Type = MagicType.AGGRESSIVE,
							IconPos = Vector(0,0),
						},
						[MagicName.HEALING] = {
							Name = {
								["Light"] = {en = "Healing",zh = "治疗术",},
							},
							CD = {
								STD = 80 * 60,	--标准恢复时间（常量）
								Current = 0,	--当前剩余恢复时间（变量）
							},
							Cost = 25,
							Reberu = 0,
							Type = MagicType.DEFENSIVE,
							IconPos = Vector(0,0),
						},
						[MagicName.DIACUTE] = {
							Name = {
								["Light"] = {en = "Diacute",zh = "二阶强化术",},
								["Dark"] = {en = "Labyrinth",zh = "幻惑强化术",},
							},
							CD = {
								STD = 60 * 60,
								Current = 0,
							},
							Cost = 15,
							OrbsCount = 0,		--光球数量
							Reberu = 0,
							Type = MagicType.SPECIAL,
							IconPos = Vector(0,0),
						},
						[MagicName.BAYOEN] = {
							Name = {
								["Light"] = {en = "Bayoen",zh = "繁花乱象",},
								["Dark"] = {en = "Ragnarok",zh = "末世幻象",},
							},
							CD = {
								STD = 100 * 60,
								Current = 0,
							},
							Cost = 25,
							Reberu = 0,
							Type = MagicType.DEFENSIVE,
							IconPos = Vector(0,0),
						},
						[MagicName.BARRIER] = {
							Name = {
								["Light"] = {en = "Revia",zh = "荆棘障壁",},
								["Dark"] = {en = "Void Hole",zh = "虚空虹洞",},
								["Void"] = {en = "Barrier", zh = "屏障术",},
							},
							CD = {
								STD = 60 * 60,
								Current = 0,
							},
							Cost = 20,
							Reberu = 0,
							Type = MagicType.DEFENSIVE,
							IconPos = Vector(0,0),
						},
						[MagicName.JUGEM] = {
							Name = {
								["Light"] = {en = "Jugem",zh = "气爆弹",},
							},
							CD = 0,
							Cost = 5,
							CostCP = 0,			--瞄准目标数量（静态变量）
							TargetAmount = 4,	--目标数量上限（常量）
							CostDesc = {
								en = "5 points per target",
								zh = "每个目标5点",
							},
							Reberu = 0,
							Type = MagicType.LOCKON,
							------v0.0.1改动------
							DMGMulti = 20,		--该法术专用的伤害倍率（常量）
							------
							IconPos = Vector(0,0),
						},
						[MagicName.LWARKWOID] = {
							Name = {
								["Light"] = {en = "",zh = "",},
								["LightB"] = {en = "Lwark Woid",zh = "吸星术",},
							},
							CD = {
								STD = 1 * 60,
								Current = 0,
							},
							Cost = 0,
							Reberu = 0,
							Type = MagicType.DEFENSIVE,
							IconPos = Vector(0,0),
						},
						[MagicName.DARKSLASH] = {
							Name = {
								["Light"] = {en = "",zh = "",},
								["Dark"] = {en = "Dark Slash",zh = "暗黑裂隙",},
							},
							CD = 0,
							Cost = 2,
							CostCP = 0,
							TargetAmount = 6,
							CostDesc = {
								en = "2 points per target",
								zh = "每个目标2点",
							},
							--测试用
							Reberu = 1,
							--
							Type = MagicType.LOCKON,
							DMGMulti = 1.5,
							IconPos = Vector(0,0),
						},
						[MagicName.GRANDCROSS] = {
							Name = {
								["Light"] = {en = "",zh = "",},
								["Dark"] = {en = "Grand Cross",zh = "灾星阵",},
							},
							--测试用
							CD = {
								STD = 3 * 60,
								Current = 0,
							},
							Cost = 10,
							Reberu = 1,
							----
							Type = MagicType.DEFENSIVE,
							IconPos = Vector(0,0),
						},
					},
				}
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.CharacterReset, 0)

	--经验值与等级
		function tbom:Character_LevelUp(player)
			local data = player:GetData()
			local HUD = Game():GetHUD()
			local arleData = data.ArleData
			local magic_data = data.MagicData
			local EXPtexts = {
				en = {
					Name = "Level up! ",
					Desc = {
						[2] = 'You unlocked "'..magic_data.Magic[4].Name["Light"].en..'" ! ',
						[3] = 'You unlocked "'..magic_data.Magic[5].Name["Light"].en..'" ! ',
						[5] = 'You unlocked "'..magic_data.Magic[3].Name["Light"].en..'" ! ',
						[7] = '"'..magic_data.Magic[1].Name["Light"].en..'" has upgraded! ',
						[9] = '"'..magic_data.Magic[2].Name["Light"].en..'" has upgraded! ',
						[11] = '"'..magic_data.Magic[3].Name["Light"].en..'" has upgraded! ',
						[13] = '"'..magic_data.Magic[5].Name["Light"].en..'" has upgraded! ',
						[14] = 'You unlocked "'..magic_data.Magic[6].Name["Light"].en..'" ! ',
						[15] = "The depth grows restless... ",
						[16] = '"'..magic_data.Magic[1].Name["Light"].en..'" has upgraded! ',
						[18] = '"'..magic_data.Magic[2].Name["Light"].en..'" has upgraded! ',
						[20] = 'You unlocked "'..magic_data.Magic[7].Name["Light"].en..'" ! ',
						[22] = '"'..magic_data.Magic[3].Name["Light"].en..'" has upgraded! ',
						[24] = '"'..magic_data.Magic[5].Name["Light"].en..'" has upgraded! ',
						[25] = "Screams are echoing from the womb... ",
						[26] = '"'..magic_data.Magic[1].Name["Light"].en..'" has upgraded! ',
						[28] = '"'..magic_data.Magic[2].Name["Light"].en..'" has upgraded! ',
						[30] = '"'..magic_data.Magic[3].Name["Light"].en..'" has upgraded! ',
					},
				},
				zh = {
					Name = "等级上升",
					Desc = {
						[2] = "你解锁了“"..magic_data.Magic[4].Name["Light"].zh.."”！",
						[3] = "你解锁了“"..magic_data.Magic[5].Name["Light"].zh.."”！",
						[5] = "你解锁了“"..magic_data.Magic[3].Name["Light"].zh.."”！",
						[7] = "“"..magic_data.Magic[1].Name["Light"].zh.."”已升级！",
						[9] = "“"..magic_data.Magic[2].Name["Light"].zh.."”已升级！",
						[11] = "“"..magic_data.Magic[3].Name["Light"].zh.."”已升级！",
						[13] = "“"..magic_data.Magic[5].Name["Light"].zh.."”已升级！",
						[14] = "你解锁了“"..magic_data.Magic[6].Name["Light"].zh.."”！",
						[15] = "深牢变得焦躁不安...",
						[16] = "“"..magic_data.Magic[1].Name["Light"].zh.."”已升级！",
						[18] = "“"..magic_data.Magic[2].Name["Light"].zh.."”已升级！",
						[20] = "你解锁了“"..magic_data.Magic[7].Name["Light"].zh.."”！",
						[22] = "“"..magic_data.Magic[3].Name["Light"].zh.."”已升级！",
						[24] = "“"..magic_data.Magic[5].Name["Light"].zh.."”已升级！",
						[25] = "子宫中回荡着尖叫声...",
						[26] = "“"..magic_data.Magic[1].Name["Light"].zh.."”已升级！",
						[28] = "“"..magic_data.Magic[2].Name["Light"].zh.."”已升级！",
						[30] = "“"..magic_data.Magic[3].Name["Light"].zh.."”已升级！",
					},
				},
			}
			if (magic_data.Magic[5].Reberu > 0) then
				EXPtexts.zh.Desc[3] = "“"..magic_data.Magic[5].Name["Light"].zh.."”已升级！"
				EXPtexts.en.Desc[3] = '"'..magic_data.Magic[5].Name["Light"].en..'" has upgraded! '
			end
			------v0.1.0新增
			local canUnlockMagic = true
			if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER then
				canUnlockMagic = false
			end
			if not canUnlockMagic then
				EXPtexts.zh.Desc = {
					[15] = "深牢变得焦躁不安...",
					[25] = "子宫中回荡着尖叫声...",
				}
				EXPtexts.en.Desc = {
					[15] = "The depth grows restless... ",
					[25] = "Screams are echoing from the womb... ",
				}
			end
			------
			if arleData.ReberuCount < arleData.Reberu then
				if (Options.Language == "zh") then
					HUD:ShowItemText(EXPtexts.zh.Name, (EXPtexts.zh.Desc[arleData.Reberu] or ""))
				else
					HUD:ShowItemText(EXPtexts.en.Name, (EXPtexts.en.Desc[arleData.Reberu] or ""))
				end
				------v0.1.0新增
				if canUnlockMagic then
					if arleData.Reberu == 2 then
						magic_data.Magic[4].Reberu = magic_data.Magic[4].Reberu + 1
					elseif (arleData.Reberu == 7 or arleData.Reberu == 16 or arleData.Reberu == 26) then
						magic_data.Magic[1].Reberu = magic_data.Magic[1].Reberu + 1
					elseif (arleData.Reberu == 9 or arleData.Reberu == 18 or arleData.Reberu == 28) then
						magic_data.Magic[2].Reberu = magic_data.Magic[2].Reberu + 1
					elseif (arleData.Reberu == 5 or arleData.Reberu == 11 or arleData.Reberu == 22 or arleData.Reberu == 30) then
						magic_data.Magic[3].Reberu = magic_data.Magic[3].Reberu + 1
					elseif (arleData.Reberu == 3 or arleData.Reberu == 13 or arleData.Reberu == 24) then
						magic_data.Magic[5].Reberu = magic_data.Magic[5].Reberu + 1
					elseif arleData.Reberu == 14 then
						magic_data.Magic[6].Reberu = magic_data.Magic[6].Reberu + 1
					elseif arleData.Reberu == 20 then
						magic_data.Magic[7].Reberu = magic_data.Magic[7].Reberu + 1
					end
				end
				------

				--以下为升级奖励
				--随机属性加成
				local caflag = math.random(1,5)
				if caflag == 3 then		--规定:升级时不改变弹速
					caflag = 10
				else
					caflag = caflag - 1
				end
				table.insert(arleData.CacheFlags, (1 << caflag))
				player:AddCacheFlags(1 << caflag)
				player:EvaluateItems()
				--回满红心
				player:AddHearts(24)
				--魔导力上限提高
				local BonusMana = 5
				if arleData.ReberuCount <= 5 then
					BonusMana = 10
				end
				magic_data.PlayerData.MadouJyougen = magic_data.PlayerData.MadouJyougen + BonusMana
				--回满魔导力
				magic_data.PlayerData.MadouRyoku = magic_data.PlayerData.MadouJyougen

				arleData.ReberuCount = arleData.ReberuCount + 1
			end
		end
		tbom:AddPriorityCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,CallbackPriority.LATE,tbom.Character_LevelUp)		--此处不可用ModCallbacks.MC_POST_PLAYER_RENDER，否则调用HUD():ShowItemText()时会造成贴图出错的bug

		function tbom:Character_LevelUpEffect(player, caflag)
			local playerType = player:GetPlayerType()
			if playerType == arlePlayerType then
				--初始属性
				if caflag == CacheFlag.CACHE_DAMAGE then
					player.Damage = player.Damage - 0.5
				end
				if caflag == CacheFlag.CACHE_FIREDELAY then
					player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) - 0.2) - 1)
				end
				if caflag == CacheFlag.CACHE_RANGE then
					player.TearRange = player.TearRange - 40
				end
				if caflag == CacheFlag.CACHE_SPEED then
					player.MoveSpeed = player.MoveSpeed - 0.1
				end

				for i, flags in pairs(arleData.CacheFlags) do
					if flags == CacheFlag.CACHE_DAMAGE and caflag == CacheFlag.CACHE_DAMAGE then
						player.Damage = player.Damage + 0.2
					end
					if flags == CacheFlag.CACHE_FIREDELAY and caflag == CacheFlag.CACHE_FIREDELAY then
						player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) + 0.1) - 1)
					end
					if flags == CacheFlag.CACHE_RANGE and caflag == CacheFlag.CACHE_RANGE then
						player.TearRange = player.TearRange + 20
					end
					if flags == CacheFlag.CACHE_SPEED and caflag == CacheFlag.CACHE_SPEED then
						player.MoveSpeed = player.MoveSpeed + 0.05
					end
					if flags == CacheFlag.CACHE_LUCK and caflag == CacheFlag.CACHE_LUCK then
						player.Luck = player.Luck + 0.2
					end
				end
			elseif playerType == doppelPlayerType then
				--初始属性
				if caflag == CacheFlag.CACHE_DAMAGE then
					player.Damage = player.Damage * 1.24
				end
				if caflag == CacheFlag.CACHE_FIREDELAY then
					player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) + 0.1) - 1)
				end
				if caflag == CacheFlag.CACHE_SHOTSPEED then
					player.ShotSpeed = player.ShotSpeed + 0.1
				end
				if caflag == CacheFlag.CACHE_SPEED then
					player.MoveSpeed = player.MoveSpeed - 0.1
				end
				if caflag == CacheFlag.CACHE_LUCK then
					player.Luck = player.Luck - 0.1
				end
				if caflag == CacheFlag.CACHE_TEARFLAG then
					player.TearFlags = player.TearFlags | TearFlags.TEAR_SPECTRAL
				end

				for i, flags in pairs(arleData.CacheFlags) do
					if flags == CacheFlag.CACHE_DAMAGE and caflag == CacheFlag.CACHE_DAMAGE then
						player.Damage = player.Damage + 0.1
					end
					if flags == CacheFlag.CACHE_FIREDELAY and caflag == CacheFlag.CACHE_FIREDELAY then
						player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) + 0.05) - 1)
					end
					if flags == CacheFlag.CACHE_RANGE and caflag == CacheFlag.CACHE_RANGE then
						player.TearRange = player.TearRange + 10
					end
					if flags == CacheFlag.CACHE_SPEED and caflag == CacheFlag.CACHE_SPEED then
						player.MoveSpeed = player.MoveSpeed + 0.03
					end
					if flags == CacheFlag.CACHE_LUCK and caflag == CacheFlag.CACHE_LUCK then
						player.Luck = player.Luck + 0.1
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_EVALUATE_CACHE,tbom.Character_LevelUpEffect)

		local function Character_EXPSpawn(player, position, num)
			for i = 1, num do
				local velocity = RandomVector() * 30
				local effect = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.EXP, 0, position, velocity, player)
				effect.Target = player
			end
		end


		function EXP_isFinalBoss(entity)
			local FinalBosses = {
				------v0.0.1改动------
				[1] = {Type = EntityType.ENTITY_MOM, Variant = 10, EXPamount = 40,},
				------
				[2] = {Type = EntityType.ENTITY_MOMS_HEART, Variant = 0, AltVariant = 1, EXPamount = 50,},
				[3] = {Type = EntityType.ENTITY_MOMS_HEART, Variant = 1, AltVariant = 0, EXPamount = 50,},
				[4] = {Type = EntityType.ENTITY_SATAN, Variant = 10, EXPamount = 100 / 2,},
				[5] = {Type = EntityType.ENTITY_ISAAC, Variant = 0, AltVariant = 1, EXPamount = 100,},
				[6] = {Type = EntityType.ENTITY_ISAAC, Variant = 1, AltVariant = 0, EXPamount = 150,},
				[7] = {Type = EntityType.ENTITY_THE_LAMB, Variant = 0, EXPamount = 150,},
				[8] = {Type = EntityType.ENTITY_MEGA_SATAN_2, Variant = 0, FalseType = EntityType.ENTITY_MEGA_SATAN, EXPamount = 200,},
				[9] = {Type = EntityType.ENTITY_HUSH, Variant = 0, EXPamount = 200,},
				[10] = {Type = EntityType.ENTITY_DELIRIUM, Variant = 0, EXPamount = 300,},
				[11] = {Type = EntityType.ENTITY_ULTRA_GREED, Variant = 1, EXPamount = 0,},
				[12] = {Type = EntityType.ENTITY_MOTHER, Variant = 10, EXPamount = 0,},
				[13] = {Type = EntityType.ENTITY_DOGMA, Variant = 0, EXPamount = 150,},
				[14] = {Type = EntityType.ENTITY_BEAST, Variant = 0, EXPamount = 0,},
			}
			for i = 1, #FinalBosses do
				if entity.Type == FinalBosses[i].Type then
					if entity.Variant == FinalBosses[i].Variant then
						return FinalBosses[i].EXPamount
					elseif FinalBosses[i].AltVariant and (entity.Variant == FinalBosses[i].AltVariant) then
						goto FinalBosses_continue
					else
						return 0
					end
				elseif FinalBosses[i].FalseType and (entity.Type == FinalBosses[i].FalseType) then
					return 0
				end
				::FinalBosses_continue::
			end
			return nil
		end

		function tbom:Character_EXPGet(npc)
			local player = Game():GetPlayer(0)
			local playerType = player:GetPlayerType()
			local magic_attribute = magic_data.PlayerData.MagicAttribute

			if canGetEXP(player) then
				local room = Game():GetRoom()
				local hp = npc.MaxHitPoints
				local amount = math.max(1, math.floor(hp / 20))

				--不要把判断妈腿是否死亡放在这里，否则BOSS战音乐不会停止

				if npc:IsBoss() and npc.Type == EntityType.ENTITY_MOMS_HEART and (not arleData.MomsHeartKilled) then
					local EXPtexts = {
						en = {
							Name = "Magic power up! ",
							Desc =  "You have unlocked "..magic_data.Magic[5].Name[magic_attribute].en.."! "
						},
						zh = {
							Name = "魔法强化",
							Desc =  "你解锁了“"..magic_data.Magic[5].Name[magic_attribute].zh.."”！"
						},
					}
					if (magic_data.Magic[5].Reberu > 0) then
						EXPtexts.zh.Desc = "“"..magic_data.Magic[5].Name[magic_attribute].zh.."”已升级！"
						EXPtexts.en.Desc = '"'..magic_data.Magic[5].Name[magic_attribute].en..'" has upgraded! '
					end
					local HUD = Game():GetHUD()
					------v0.1.0改动
					local canUnlockMagic = true
					if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER then
						canUnlockMagic = false
					end
					if canUnlockMagic then
						if (Options.Language == "zh") then
							HUD:ShowItemText(EXPtexts.zh.Name, EXPtexts.zh.Desc)
						else
							HUD:ShowItemText(EXPtexts.en.Name, EXPtexts.en.Desc)
						end
						magic_data.Magic[5].Reberu = magic_data.Magic[5].Reberu + 1
					end
					------
					local HeartEXPAmount = 50
					if player:HasCollectible(CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
						HeartEXPAmount = Fix_Round(HeartEXPAmount * (math.max(100, 400 - room:GetFrameCount()) / 100), 0)
					end
					if arleData.EXP >= (Reberu2EXP(25) - HeartEXPAmount) then
						room:TrySpawnBlueWombDoor(false, true)
					end

					magic_data.PlayerData.MomsHeartKilled = true
				end

				if npc:IsBoss() then
					local amount_fixed = EXP_isFinalBoss(npc)
					if amount_fixed ~= nil then
						amount = amount_fixed
						Character_EXPSpawn(player, npc.Position, amount)
						return
					end
				end
				if (not npc:HasEntityFlags(EntityFlag.FLAG_ICE_FROZEN)) then
					if not (npc.ParentNPC) and (not EntityRef(npc).IsFriendly) then
						if (not npc.SpawnerType) or npc.SpawnerType == 0 then
							if npc:IsChampion() then
								amount = amount + 1
							end
							if player:HasCollectible(CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
								arleData.FlashShootBonus = math.max(100, 400 - room:GetFrameCount()) / 100
								amount = Fix_Round(amount * (arleData.FlashShootBonus), 0)
							end
							Character_EXPSpawn(player, npc.Position, amount)
							return
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_NPC_DEATH,tbom.Character_EXPGet,nil)

		function tbom:Character_IcedEXPGet(entity)
			local player = Game():GetPlayer(0)
			local room = Game():GetRoom()

			------v0.0.1改动------
			if entity:IsBoss() and entity.Type == EntityType.ENTITY_MOM and entity.Variant == 10 and (not arleData.MomKilled) then
				arleData.MomKilled = true
				local MomEXPAmount = 40
				if player:HasCollectible(CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
					MomEXPAmount = Fix_Round(MomEXPAmount * (math.max(100, 400 - room:GetFrameCount()) / 100), 0)
				end
				if arleData.EXP >= (Reberu2EXP(15) - MomEXPAmount) then
					room:TrySpawnBossRushDoor(true)
				end
			end
			------

			if entity:IsActiveEnemy(true) and entity:HasEntityFlags(EntityFlag.FLAG_ICE) and (not entity:HasEntityFlags(EntityFlag.FLAG_ICE_FROZEN)) then
				local npc = entity:ToNPC()
				local playerType = player:GetPlayerType()
				if canGetEXP(player) then
					
					local hp = npc.MaxHitPoints
					local amount = math.max(1, math.floor(hp / 20))

					if (not EntityRef(npc).IsFriendly) then
						if (not npc.SpawnerType) or npc.SpawnerType == 0 then
							if npc:IsChampion() then
								amount = amount + 1
							end
							if player:HasCollectible(CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
								arleData.FlashShootBonus = math.max(100, 400 - room:GetFrameCount()) / 100
								amount = Fix_Round(amount * (arleData.FlashShootBonus), 0)
							end
							Character_EXPSpawn(player, npc.Position, amount)
							return
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL,tbom.Character_IcedEXPGet,nil)

		function tbom:Character_TrySpawnDoor()
			local level = Game():GetLevel()
			local stage = level:GetStage()
			if arleData.MomKilled and arleData.Reberu >= 15 and (stage == LevelStage.STAGE3_1 or stage == LevelStage.STAGE3_2) then		--考虑迷宫诅咒
				local room = level:GetCurrentRoom()
				if room:IsClear() and room:GetBossID() == 6 then	--v0.1.1修复
					room:TrySpawnBossRushDoor(true)
				end
			end
			------v0.0.3修复------
			if arleData.MomsHeartKilled and arleData.Reberu >= 25 and (stage == LevelStage.STAGE4_1 or stage == LevelStage.STAGE4_2) then
				local room = level:GetCurrentRoom()
				if room:IsClear() then
					room:TrySpawnBlueWombDoor(true, true)
				end
			end
			----------------------
		end
		tbom:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,tbom.Character_TrySpawnDoor)

		function tbom:Character_EXPInit(effect)
			effect:SetColor(Color(0, 1, 0, 1, 0, 0, 0), -1, 0)
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_INIT, tbom.Character_EXPInit, modEffectVariant.EXP)
    
		function tbom:Character_EXPUpdate(effect)
			if effect.Variant == modEffectVariant.EXP then
				if (not effect.Child) then
					local trail = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, effect.Position, Vector.Zero, effect):ToEffect()
					trail.Parent = effect
					trail.MinRadius = 0.15
					trail.MaxRadius = 0.15
					trail.SpriteScale = Vector(2,2)
					trail:SetColor(Color(0.25, 0.5, 0.25, 0.5, 0, 0, 0), -1, 0)
					effect.Child = trail
				else 
					effect.Child.Position = effect.Position + Vector(0,-24)
				end

				local sprite = effect:GetSprite()
				if effect.State == 0 then
					if (effect.Target and effect.Target:Exists()) then
						sprite:Play("Move")

						local velocity = effect.Velocity
						local dir = effect.Target.Position - effect.Position
                    
						local speed = math.min(velocity:Length() + 1, 20)
						effect.Velocity = effect.Velocity * 0.8 + dir:Resized(20) * 0.2

						if (effect.Target.Position:Distance(effect.Position) <= effect.Target.Size and effect.FrameCount > 10) then
							SFXManager():Play(SoundID.expget)
							effect.Position = effect.Target.Position;
							effect.State = 1
							effect.Velocity = Vector.Zero
							arleData.EXP = arleData.EXP + 1
						end
					else
						sprite:Play("Idle")
						effect:MultiplyFriction(0.9)
					end
				else
					sprite:Play("Collect")
					if (sprite:IsFinished("Collect")) then
						effect:Remove()
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, tbom.Character_EXPUpdate)

		function tbom:Character_EXPRemove(entity)
			if (entity.Type == EntityType.ENTITY_EFFECT and entity.Variant == modEffectVariant.EXP) then
				if (entity.Child and entity.Child:Exists()) then
					entity.Child:Remove()
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_ENTITY_REMOVE, tbom.Character_EXPRemove)

		function tbom:Character_Data(player)
			local data = magic_data
			------v0.1.0修复
			data.PlayerData.MadouRyoku = Fix_Round(data.PlayerData.MadouRyoku, 1)
			------
			if data.PlayerData.MadouRyoku > data.PlayerData.MadouJyougen then
				data.PlayerData.MadouRyoku = data.PlayerData.MadouJyougen
			end
			if data.PlayerData.MadouRyoku < 0 then
				data.PlayerData.MadouRyoku = 0
			end
			arleData.Reberu = EXP2Reberu(arleData.EXP)

			if (not Game():IsPaused()) then
				for _,i in pairs(data.PlayerData.UseableMagic) do
					if data.Magic[i].Type ~= MagicType.AGGRESSIVE and data.Magic[i].Type ~= MagicType.LOCKON then
						if data.Magic[i].CD.Current > 0 then
							data.Magic[i].CD.Current = data.Magic[i].CD.Current - 1
						end
					elseif data.Magic[i].Type == MagicType.AGGRESSIVE then
						if data.Magic[i].CD == 1 then
							if data.Magic[i].CostCP == 0 then
								data.PlayerData.MadouRyoku = data.PlayerData.MadouRyoku - data.Magic[i].Cost
							end
							data.Magic[i].CostCP = (data.Magic[i].CostCP + 1) % 60
						end
					end
				end

				local current_magic = data.Magic[data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]]
				if current_magic and (data.PlayerData.MadouRyoku < current_magic.Cost) and data.PlayerData.UsingAggressiveMagic then		--对于攻击性法术，当魔导力低于每秒消耗量时，强制终止使用法术
					if current_magic.Type == MagicType.AGGRESSIVE then
						current_magic.CD = 0
						data.PlayerData.UsingAggressiveMagic = false
						player:AddCacheFlags(CacheFlag.CACHE_LUCK | CacheFlag.CACHE_FIREDELAY | CacheFlag.CACHE_DAMAGE | CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_TEARCOLOR)
						player:EvaluateItems()
						player:SetColor(Color(1,1,1,1,0.5,0.5,0.5), 6, -1, true)
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.Character_Data)

		function tbom:Character_EXPBar()	--经验值进度条
			local player = Game():GetPlayer(0)
			local playerType = player:GetPlayerType()
		    if canGetEXP(player) then
				if not Game():GetSeeds():HasSeedEffect(SeedEffect.SEED_NO_HUD) and Game():GetHUD():IsVisible() == true then
					local EXPbar = Sprite()
					EXPbar:Load("gfx/tbom/ui/EXPbar.anm2")
					EXPbar:Play("Idle")
					local hud_offset = Options.HUDOffset
					local barX = 158 + 20 * hud_offset
					local barY = 20 + 12 * hud_offset
					local bar_pos = Vector(barX, barY)
					local EXPrate = Fix_Round(((arleData.EXP - Reberu2EXP(arleData.Reberu)) / (Reberu2EXP(arleData.Reberu + 1) - Reberu2EXP(arleData.Reberu))), 3)
					local frame = math.floor(EXPrate * 20)
					EXPbar:SetFrame(frame)
					EXPbar:Render(bar_pos)

					local font = FontList[Options.Language] or FontList.en
					font:DrawStringUTF8("Lv. "..arleData.Reberu, barX - 4, barY - 16, KColor(1,1,1,0.8), 10, true)
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_RENDER,tbom.Character_EXPBar)

		local DMGfluctuation_DONE = false

		function tbom:Character_daidageki(took_dmg, dmg_amount, dmg_flags, dmg_source, dmg_countdown_frames)	--暴击率
			local player = Game():GetPlayer(0)
			local CriticalRand = math.random(1, 100)
			local CriticalChance = 4
			CriticalChance = math.max(1, CriticalChance + Fix_Round(player.Luck, 0) + (player:GetTrinketMultiplier(TrinketType.TRINKET_TEARDROP_CHARM) * 3))
			if player:GetPlayerType() == arlePlayerType and (not DMGfluctuation_DONE) then
				if took_dmg:IsActiveEnemy() and took_dmg:IsVulnerableEnemy() then
					DMGfluctuation_DONE = true
					if CriticalRand <= CriticalChance then
						took_dmg:TakeDamage(dmg_amount, dmg_flags | DamageFlag.DAMAGE_IGNORE_ARMOR | DamageFlag.DAMAGE_CLONES, dmg_source, 0)
					end
					DMGfluctuation_DONE = false
				end
			end
		end
		tbom:AddPriorityCallback(ModCallbacks.MC_ENTITY_TAKE_DMG,CallbackPriority.LATE,tbom.Character_daidageki)

		local DMGdouble_DONE = false

		function tbom:Character_glasscannon(took_dmg, dmg_amount, dmg_flags, dmg_source, dmg_countdown_frames)
			local player = took_dmg:ToPlayer()
			local playerType = player:GetPlayerType()
			if playerType == doppelPlayerType 
			and (not (dmg_flags & DamageFlag.DAMAGE_CURSED_DOOR > 0 or dmg_flags & DamageFlag.DAMAGE_IV_BAG > 0 or dmg_flags & DamageFlag.DAMAGE_DEVIL > 0))
			and (not DMGdouble_DONE) then
				DMGdouble_DONE = true
				took_dmg:TakeDamage(dmg_amount, dmg_flags | DamageFlag.DAMAGE_CLONES, dmg_source, 0)
				DMGdouble_DONE = false
			end
		end
		tbom:AddPriorityCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, CallbackPriority.EARLY, tbom.Character_glasscannon, EntityType.ENTITY_PLAYER)

	--蓝色魔导书
		function tbom:blueg_reset(boolean_isContinued)
			local player = Game():GetPlayer(0)

			if not boolean_isContinued then
				magic_data.PlayerData = {
					MadouRyoku = 5,
					MadouJyougen = 20,
					MagicAttribute = "Void",
					CurrentMagicKey = 1,
					UseableMagic = {1,2,3,4,5,6,7,8},
					UseableVoidMagic = {[1] = 0, [2] = 0, [3] = 0,},
					UsingAggressiveMagic = false,
					UsedAggressiveMagic = false,
					HasBarrier = 0,
					MagicCircle = nil,
					LaserSight = nil,
					LockonTargetHeap = {},
					LockonCount = 0,
					LockonDMGMulti = 1,
					TearFlagSeed = 0,
					SelfFireDelay = 0,
					FamiliarFireDelay = 0,
					VoidCount = 0,
				}
				for i,j in pairs(magic_data.Magic) do
				--测试用
					--magic_data.Magic[i].Reberu = 0
					--
					if magic_data.Magic[i].Type == MagicType.AGGRESSIVE or magic_data.Magic[i].Type == MagicType.LOCKON then
						magic_data.Magic[i].CostCP = 0
						magic_data.Magic[i].CD = 0
					else
						magic_data.Magic[i].CD.Current = 0
						if magic_data.Magic[i].Type == MagicType.SPECIAL then
							magic_data.Magic[i].OrbsCount = 0
						end
					end
				end

				------v0.0.2修复------
				player:AddCacheFlags(CacheFlag.CACHE_LUCK | CacheFlag.CACHE_FIREDELAY | CacheFlag.CACHE_DAMAGE | CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_TEARCOLOR | CacheFlag.CACHE_FAMILIARS)
				----------------------
				player:EvaluateItems()

				local playerType = player:GetPlayerType()
				if playerType == arlePlayerType then
					magic_data.PlayerData.MadouRyoku = 20
					magic_data.PlayerData.MagicAttribute = "Light"
					magic_data.PlayerData.UseableMagic = {1,2,3,4,5,6,7,8}
					magic_data.Magic[1].Reberu = 1
					magic_data.Magic[2].Reberu = 1
				elseif playerType == doppelPlayerType then
					magic_data.PlayerData.MadouRyoku = 20
					magic_data.PlayerData.MagicAttribute = "Dark"
					magic_data.PlayerData.UseableMagic = {1,2,MagicName.DARKSLASH,4,5,6,7,MagicName.GRANDCROSS}
					magic_data.Magic[1].Reberu = 1
					magic_data.Magic[2].Reberu = 1
				end
				------v0.0.3
				for i, entity in pairs(Isaac.GetRoomEntities()) do
					if entity.Type == EntityType.ENTITY_EFFECT and entity.Variant == modEffectVariant.LOCKONMARK then
						entity:Remove()
					end
					if entity.Type == EntityType.ENTITY_EFFECT and entity.Variant == modEffectVariant.LASERSIGHT then
						entity:Remove()
						magic_data.PlayerData.LaserSight = nil
					end
					if entity.Type == EntityType.ENTITY_EFFECT and entity.Variant == modEffectVariant.MAGIC_CIRCLE then
						entity:Remove()
						magic_data.PlayerData.MagicCircle = nil
					end
				end
				------
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,tbom.blueg_reset)

		function tbom:bluegrimoire(item, RNG, player, use_flags, active_slot, custom_var_data)

			local data = magic_data
			local magicID = data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]
			local current_magic = data.Magic[magicID]
			local SFX = SFXManager()
			local can_add_wisp = player:HasCollectible(CollectibleType.COLLECTIBLE_BOOK_OF_VIRTUES) and (use_flags & UseFlag.USE_NOANIM == 0 or use_flags & UseFlag.USE_ALLOWWISPSPAWN > 0)
			------v0.1.0新增
			local isAllowedMagic = true
			if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER and not (magicID and magicID == 8) then
				isAllowedMagic = false
			end
			------
			local playerType = player:GetPlayerType()
			if canUseVariousSpells(player) then
				------v0.1.0新增
				if current_magic and current_magic.Reberu > 0 and isAllowedMagic then
				------
					if current_magic.Type == MagicType.AGGRESSIVE or current_magic.Type == MagicType.LOCKON then
						if data.PlayerData.MadouRyoku >= current_magic.Cost or (current_magic.Type == MagicType.LOCKON and current_magic.CD ~= 0) then
							current_magic.CD = (current_magic.CD + 1) % 2
							data.PlayerData.UsingAggressiveMagic = Xor(data.PlayerData.UsingAggressiveMagic, true)
							if current_magic.Type == MagicType.AGGRESSIVE then	--针对攻击性法术
								--触发效果函数
								if data.PlayerData.UsingAggressiveMagic then
									blueg_effect_ATK_UseItem(player, data, magicID, can_add_wisp)
									------v0.0.3
									
									SFX:Play(SoundEffect.SOUND_BOOK_PAGE_TURN_12)
									------
								end
								player:SetColor(Color(1,1,1,1,0.5,0.5,0.5), 6, -1, true)
								player:AddCacheFlags(CacheFlag.CACHE_LUCK | CacheFlag.CACHE_FIREDELAY | CacheFlag.CACHE_DAMAGE | CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_TEARCOLOR)
								player:EvaluateItems()
							end
						else
							return {ShowAnim = false, Remove = false}
						end
					else
						if data.PlayerData.MadouRyoku >= current_magic.Cost then
							if current_magic.Type == MagicType.DEFENSIVE then
								if current_magic.CD.Current == 0 then
									data.PlayerData.MadouRyoku = data.PlayerData.MadouRyoku - current_magic.Cost
									current_magic.CD.Current = current_magic.CD.STD
									blueg_effect_DEF_SPC(player, data, magicID, can_add_wisp)
								else
									return {ShowAnim = false, Remove = false}
								end
							elseif current_magic.Type == MagicType.SPECIAL then
								if magicID == 5 then
									if current_magic.CD.Current == 0 
									or current_magic.CD.Current > current_magic.CD.STD / 2 then
										if current_magic.OrbsCount < current_magic.Reberu then
											if current_magic.CD.Current == 0 then
												current_magic.CD.Current = current_magic.CD.STD
											end
											data.PlayerData.MadouRyoku = data.PlayerData.MadouRyoku - current_magic.Cost
											blueg_effect_DEF_SPC(player, data, magicID, can_add_wisp)
										else
											return {ShowAnim = false, Remove = false}
										end
									else
										return {ShowAnim = false, Remove = false}
									end
								end
							end
						else
							return {ShowAnim = false, Remove = false}
						end
					end
				else
					return {ShowAnim = false, Remove = false}
				end
				------v0.0.3改动------
				if current_magic.Type == MagicType.AGGRESSIVE or current_magic.Type == MagicType.SPECIAL then
					------v0.0.3新增------
					if current_magic.Type == MagicType.SPECIAL then
						player:SetColor(Color(1,1,1,1,0.5,0.5,0.5), 6, -1, true)
					end
					----------------------
					return {ShowAnim = false, Remove = false}
				else
					return {ShowAnim = true, Remove = false}
				end
				----------------------
			else
				------v0.0.3改动------
				if data.PlayerData.MadouRyoku + player:GetEffectiveSoulCharge() + player:GetBloodCharge() >= 5 or use_flags & UseFlag.USE_VOID > 0 then		--兼容其他角色和虚空
					if use_flags & UseFlag.USE_VOID > 0 then
						data.PlayerData.VoidCount = data.PlayerData.VoidCount + 1		--兼容虚空
					end
				----------------------
					blueg_compatibility_OnUse(player, data, can_add_wisp)
					for i = 1, 5 do
						if data.PlayerData.MadouRyoku > 0 then
							data.PlayerData.MadouRyoku = data.PlayerData.MadouRyoku - 1
						else
							player:AddSoulCharge(-1)
							player:AddBloodCharge(-1)
						end
					end
					return {ShowAnim = true, Remove = false}
				else
					return {ShowAnim = false, Remove = false}
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_USE_ITEM,tbom.bluegrimoire,ItemID.bluegrimoire)

		function tbom:blueg_effect_caflags(player, caflag)
			local tmp = player:GetEffects()
			local data = magic_data
				if data.Magic[1].CD ~= 0 then
					if data.Magic[1].Reberu >= 1 then
						if (not player:HasCollectible(CollectibleType.COLLECTIBLE_FIRE_MIND)) then
							if ((data.Magic[1].Reberu == 1 and data.PlayerData.TearFlagSeed <= 25) 
							or (data.Magic[1].Reberu >= 2 and data.PlayerData.TearFlagSeed <= 50) 
							or (data.Magic[1].Reberu >= 3 and data.PlayerData.TearFlagSeed <= 75)
							or (data.Magic[1].Reberu >= 4)) then
								if caflag == CacheFlag.CACHE_TEARFLAG then
									player.TearFlags = player.TearFlags | TearFlags.TEAR_BURN
								end
								------v0.0.3改动------
								if caflag == CacheFlag.CACHE_TEARCOLOR then
									player.TearColor = Color(1,1,1,1,0.3,0,0)
								end
								----------------------
							end
						else
							if caflag == CacheFlag.CACHE_LUCK then
								player.Luck = player.Luck + 2 * data.Magic[1].Reberu
							end
						end
					end
				end
				if data.Magic[2].CD ~= 0 then
					if data.Magic[2].Reberu >= 1 then
						if (data.Magic[2].Reberu == 1 and data.PlayerData.TearFlagSeed <= 25) 
						or (data.Magic[2].Reberu >= 2 and data.PlayerData.TearFlagSeed <= 50) 
						or (data.Magic[2].Reberu >= 3 and data.PlayerData.TearFlagSeed <= 75)
						or (data.Magic[2].Reberu >= 4) then
							if caflag == CacheFlag.CACHE_TEARFLAG then
								player.TearFlags = player.TearFlags | TearFlags.TEAR_SLOW
							end
							if caflag == CacheFlag.CACHE_TEARCOLOR then
								player.TearColor = Color(0.518, 0.671, 0.976, 1, 0.14, 0.16, 0.18)
							end
						end
						if (not player:HasCollectible(CollectibleType.COLLECTIBLE_URANUS)) then
							if (data.Magic[2].Reberu == 2 and data.PlayerData.TearFlagSeed % 50 <= 12) 
							or (data.Magic[2].Reberu == 3 and data.PlayerData.TearFlagSeed % 50 <= 25) 
							or (data.Magic[2].Reberu >= 4) then
								if caflag == CacheFlag.CACHE_TEARFLAG then
									player.TearFlags = player.TearFlags | TearFlags.TEAR_ICE
								end
								if caflag == CacheFlag.CACHE_TEARCOLOR then
									player.TearColor = Color(0.518, 0.671, 0.976, 1, 0.35, 0.4, 0.45)
								end
							end
						else
							if caflag == CacheFlag.CACHE_FIREDELAY then
								player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) + 1 * (data.Magic[2].Reberu - 1)) - 1)
							end
						end
					end
				end
				if data.Magic[3].CD ~= 0 then
					if data.Magic[3].Reberu >= 1 then
						if (not player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO)) then
							if caflag == CacheFlag.CACHE_TEARFLAG then
								player.TearFlags = player.TearFlags | TearFlags.TEAR_LASER
							end
						end
						if player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO) or (not player:HasWeaponType(WeaponType.WEAPON_TEARS)) then
							if caflag == CacheFlag.CACHE_DAMAGE then
								player.Damage = player.Damage + 2
							end
						end
					end
					if data.Magic[3].Reberu >= 2 then
						if (not player:HasCollectible(CollectibleType.COLLECTIBLE_JACOBS_LADDER)) then
							if caflag == CacheFlag.CACHE_TEARFLAG then
								player.TearFlags = player.TearFlags | TearFlags.TEAR_JACOBS
							end
						else
							if caflag == CacheFlag.CACHE_DAMAGE then
								player.Damage = player.Damage + 2
							end
						end
					end
					if data.Magic[3].Reberu >= 3 
					and data.PlayerData.TearFlagSeed <= 50 then
						if caflag == CacheFlag.CACHE_TEARFLAG then
							player.TearFlags = player.TearFlags | TearFlags.TEAR_CONFUSION
						end
						if caflag == CacheFlag.CACHE_TEARCOLOR then
							player.TearColor = Color(1, 1, 0, 1, 0.5, 0.5, 0)
						end
					end
					if data.Magic[3].Reberu >= 4 
					and (data.PlayerData.TearFlagSeed) % 50 <= 25 then
						if caflag == CacheFlag.CACHE_TEARFLAG then
							player.TearFlags = player.TearFlags | TearFlags.TEAR_FREEZE
						end
						if caflag == CacheFlag.CACHE_TEARCOLOR then
							player.TearColor = Color(1, 1, 0, 1, 0.5, 0.5, 0.5)
						end
					end
				end
			if caflag == CacheFlag.CACHE_FAMILIARS then
				local playerType = player:GetPlayerType()
				if playerType == arlePlayerType then
					player:CheckFamiliar(modFamiliarVariant.LIGHT_ORB, magic_data.Magic[5].OrbsCount, RNG(), nil)
				elseif playerType == doppelPlayerType then
					player:CheckFamiliar(modFamiliarVariant.LIGHT_ORB, magic_data.Magic[5].OrbsCount * 2, RNG(), nil)
				end
			end
			if caflag == CacheFlag.CACHE_DAMAGE and player:HasCollectible(CollectibleType.COLLECTIBLE_BOOK_OF_BELIAL_PASSIVE) then
				
			end
		end
		tbom:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, tbom.blueg_effect_caflags)

		--[[function ShootDirection_Fixed(mov_dir, shoot_dir, multiplier)
			local fixed_dir = shoot_dir
			if not (mov_dir.X * shoot_dir.X < 0) then		--已弃用：直接比较角色速度分量会造成灾难性的bug
				fixed_dir.X = shoot_dir.X + mov_dir.X * multiplier
			end
			if not (mov_dir.Y * shoot_dir.Y < 0) then
				fixed_dir.Y = shoot_dir.Y + mov_dir.Y * multiplier
			end
			return fixed_dir
		end]]

		function maths_Sign(x)
			if x > 0 then
				return 1
			elseif x < 0 then
				return -1
			else
				return 0
			end
		end

		function tbom:blueg_effect_ShootUnique(player)
			local data = magic_data
			local dir = ShootDirection(player:GetFireDirection())
			if dir ~= Vector.Zero then
				data.PlayerData.SelfFireDelay = (data.PlayerData.SelfFireDelay + 1) % (math.max(1, math.floor(player.MaxFireDelay)) * 3)
				if player:HasTrinket(TrinketType.TRINKET_FORGOTTEN_LULLABY) then
					data.PlayerData.FamiliarFireDelay = (data.PlayerData.FamiliarFireDelay + 1) % (math.max(1, math.floor(player.MaxFireDelay)) * 2)
				else
					data.PlayerData.FamiliarFireDelay = (data.PlayerData.FamiliarFireDelay + 1) % (math.max(1, math.floor(player.MaxFireDelay)) * 3)
				end
			end

			--模拟角色的“甩弹”效果
			local X_hasVelocity = maths_Sign(math.max(0, math.abs(player.Velocity.X)))	--值为1则该轴上有速度分矢量，为0则无
			local Y_hasVelocity = maths_Sign(math.max(0, math.abs(player.Velocity.Y)))
			local X_isSameDir =	maths_Sign(dir.X * player.Velocity.X)	--值为1则该轴上角色朝向与速度分矢量同向，为-1则反向，为0则该轴上无与角色朝向共线的速度分矢量
			local Y_isSameDir =	maths_Sign(dir.Y * player.Velocity.Y)
			local isSwing = Vector(X_hasVelocity * maths_Sign(X_isSameDir + X_hasVelocity), Y_hasVelocity * maths_Sign(Y_isSameDir + Y_hasVelocity))	--分量为1则向该分矢量方向甩弹，分量为0则不甩弹

			local fixed_dir = (dir + player.Velocity * 0.125 * isSwing) * 10 * player.ShotSpeed

			if data.Magic[1].CD ~= 0 then
				if (data.Magic[1].Reberu == 2 and data.PlayerData.TearFlagSeed % 50 <= 5) 
				or (data.Magic[1].Reberu == 3 and data.PlayerData.TearFlagSeed % 50 <= 8) 
				or (data.Magic[1].Reberu >= 4 and data.PlayerData.TearFlagSeed % 50 <= 12) then
					if data.PlayerData.SelfFireDelay == 0 and dir ~= Vector.Zero then
						player:ShootRedCandle(dir)
						local familiars = Isaac.FindByType(EntityType.ENTITY_FAMILIAR, modFamiliarVariant.LIGHT_ORB, 0, false, false)
						for i, orb in pairs(familiars) do
							if math.random(1,4) == 1 then
								local flame = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.BLUE_FLAME, 0, orb.Position, fixed_dir, orb):ToEffect()
								flame.CollisionDamage = player.Damage * 0.2
								flame:SetTimeout(60)
							end
						end
					end
				end
			end

			if data.PlayerData.FamiliarFireDelay == 0 and dir ~= Vector.Zero then
				local familiars = Isaac.FindByType(EntityType.ENTITY_FAMILIAR, modFamiliarVariant.LIGHT_ORB, 0, false, false)
				for i, orb in pairs(familiars) do
					local tear = player:FireTear(orb.Position, fixed_dir, false, true, false, player, 0.5 * (1 + math.min(1, player:GetCollectibleNum(CollectibleType.COLLECTIBLE_BFFS)))):ToTear()
					if player:HasTrinket(TrinketType.TRINKET_BABY_BENDER) then
						tear:AddTearFlags(TearFlags.TEAR_HOMING)
						tear.Color = Color(0.4, 0.15, 0.38, 1, 0.27843, 0, 0.4549)
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, tbom.blueg_effect_ShootUnique)

		------v0.0.1改动------
		function tbom:blueg_effect_TakeDMG(took_dmg, dmg_amount, dmg_flags, dmg_source, dmg_countdown_frames)
			local player = took_dmg:ToPlayer()
			local data = magic_data
			local playerType = player:GetPlayerType()
			if canUseVariousSpells(player) then
				if (data.Magic[1].CD ~= 0 and data.Magic[1].Reberu >= 3) 
				or (data.Magic[8].Reberu > 0 and player:HasCollectible(CollectibleType.COLLECTIBLE_EPIC_FETUS)) 
				------v0.0.3改动------
				or (data.Magic[8].Reberu > 0 and data.Magic[5].OrbsCount >= 1)then		------二阶强化术------
				----------------------
					if dmg_flags & DamageFlag.DAMAGE_EXPLOSION > 0 then
						return false
					end
				end
				if data.Magic[1].CD ~= 0 and data.Magic[1].Reberu >= 2 then
					if dmg_flags & DamageFlag.DAMAGE_FIRE > 0 then
						return false
					end
				end
			end
		end
		tbom:AddPriorityCallback(ModCallbacks.MC_ENTITY_TAKE_DMG, CallbackPriority.EARLY, tbom.blueg_effect_TakeDMG, EntityType.ENTITY_PLAYER)
		------

		------v0.0.3新增------
		function tbom:blueg_effect_ATK_circle(player)
			local data = magic_data
			local magicID = data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]
			local current_magic = data.Magic[magicID]
			if current_magic and current_magic.Type == MagicType.AGGRESSIVE then
				if current_magic.CD ~= 0 then
					if (not data.PlayerData.MagicCircle or not data.PlayerData.MagicCircle:Exists()) then
						data.PlayerData.MagicCircle = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.MAGIC_CIRCLE, 0, player.Position, Vector(0,0), player):ToEffect()
						data.PlayerData.MagicCircle.Parent = player
						data.PlayerData.MagicCircle.SpriteScale = Vector(0.5, 0.5)
						data.PlayerData.MagicCircle.Position = player.Position
						--(data.PlayerData.MagicCircle):FollowParent(player)
					else
						if not (data.PlayerData.MagicCircle):GetSprite():IsPlaying("Idle") then
							(data.PlayerData.MagicCircle):GetSprite():Play("Display")
						end
					end
				else
					if data.PlayerData.MagicCircle and data.PlayerData.MagicCircle:Exists() then
						(data.PlayerData.MagicCircle):GetSprite():Play("Hide")
					end
				end
			else
				if data.PlayerData.MagicCircle and data.PlayerData.MagicCircle:Exists() then
					(data.PlayerData.MagicCircle):GetSprite():Play("Hide")
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, tbom.blueg_effect_ATK_circle)
		----------------------

		function tbom:blueg_effect_ATK_SetSeed(player)
			local data = magic_data
			local current_magic = data.Magic[data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]]
			if current_magic and current_magic.Type == MagicType.AGGRESSIVE and current_magic.CD ~= 0 then
				player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_TEARCOLOR)
				player:EvaluateItems()
				data.PlayerData.TearFlagSeed = math.random(1, 100)
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, tbom.blueg_effect_ATK_SetSeed)

		function blueg_effect_ATK_UseItem(player, data, magicID, can_add_wisp)
			local SFX = SFXManager()
			local current_magic = data.Magic[magicID]
			local entities = Isaac.GetRoomEntities()
			if current_magic and current_magic.Type == MagicType.AGGRESSIVE then
				if magicID == 1 then
					if current_magic.Reberu >= 3 and (not data.PlayerData.UsedAggressiveMagic) then
						for _,entity in pairs(entities) do
							if entity:IsActiveEnemy() and entity:IsVulnerableEnemy() then
								entity:AddBurn(EntityRef(player), 30 * 3, player.Damage * 0.25)
							end
						end
						SFX:Play(SoundEffect.SOUND_DEVILROOM_DEAL)
						data.PlayerData.UsedAggressiveMagic = true
					end
				elseif magicID == 2 then
					if current_magic.Reberu >= 3 and (not data.PlayerData.UsedAggressiveMagic) then
						for _,entity in pairs(entities) do
							if entity:IsActiveEnemy() and entity:IsVulnerableEnemy() then
								entity:AddFreeze(EntityRef(player), 30 * 3)
							end
						end
						SFX:Play(SoundEffect.SOUND_DEVILROOM_DEAL)
						data.PlayerData.UsedAggressiveMagic = true
					end
				end
			end
		end

		function tbom:blueg_effect_ATK_Reset(RNG, spawn_pos)
			local data = magic_data
			if data.PlayerData.UsedAggressiveMagic then
				data.PlayerData.UsedAggressiveMagic = false
			end
		end
		tbom:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, tbom.blueg_effect_ATK_Reset)

		local function isTaintedMonster(previousNPC)
			local type = previousNPC.Type
			local variant = previousNPC.Variant
			local TaintedMonsters = {
				[1] = {Type = EntityType.ENTITY_POOTER, Variant = 2, VariantOrig = 0,},
				[2] = {Type = EntityType.ENTITY_HIVE, Variant = 3, VariantOrig = 0,},
				[3] = {Type = EntityType.ENTITY_BOOMFLY, Variant = 6, VariantOrig = 0,},
				[4] = {Type = EntityType.ENTITY_HOPPER, Variant = 3, VariantOrig = 0,},
				[5] = {Type = EntityType.ENTITY_SPITTY, Variant = 1, VariantOrig = 0,},
				[6] = {Type = EntityType.ENTITY_SUCKER, Variant = 7, VariantOrig = 0,},
				[7] = {Type = EntityType.ENTITY_WALL_CREEP, Variant = 3, VariantOrig = 0,},
				--[8] = {Type = EntityType.ENTITY_ROUND_WORM, Variant = 2, VariantOrig = 0,},
				[8] = {Type = EntityType.ENTITY_ROUND_WORM, Variant = 3, VariantOrig = 1},
				[9] = {Type = EntityType.ENTITY_SUB_HORF, Variant = 1, VariantOrig = 0,},
				[10] = {Type = EntityType.ENTITY_FACELESS, Variant = 1, VariantOrig = 0,},
				[11] = {Type = EntityType.ENTITY_MOLE, Variant = 1, VariantOrig = 0,},
				[12] = {Type = EntityType.ENTITY_CHARGER_L2, Variant = 1, VariantOrig = 0,},
			}
			for i = 1, #TaintedMonsters do
				if TaintedMonsters[i].Type == type and variant ~= TaintedMonsters[i].Variant then
					return TaintedMonsters[i].Variant
				end
			end
			return nil
		end

		function blueg_effect_DEF_SPC(player, data, magicID, can_add_wisp)
			local SFX = SFXManager()
			if data.Magic[magicID].Type == MagicType.DEFENSIVE then
				if magicID == 4 then
					if player:GetHearts() < player:GetEffectiveMaxHearts() then
						player:AddHearts(2)
					else
						player:AddSoulHearts(1)
					end
					SFX:Play(SoundEffect.SOUND_VAMP_GULP)
					----二阶强化术----
					data.Magic[4].CD.Current = data.Magic[4].CD.Current - data.Magic[5].OrbsCount * 5 * 60
					if can_add_wisp then
						player:AddWisp(45, player.Position)		--红心魂火
					end
				elseif magicID == 6 then
					----二阶强化术----
					if data.Magic[5].OrbsCount >= 1 then		--如果使用了二阶强化术，则将能堕化的怪物堕化并魅惑之
						for _,entity in pairs(Isaac.GetRoomEntities()) do
							if entity:IsActiveEnemy() and entity:IsVulnerableEnemy() then
								local NPC = entity:ToNPC()
								if not (NPC:IsBoss() or (NPC.SpawnerEntity and NPC.SpawnerEntity:IsBoss())) then	--对于BOSS生成的怪物，只魅惑10秒，且不会被堕化
									local newNPC = isTaintedMonster(NPC)
									if newNPC ~= nil then
										Isaac.Spawn(NPC.Type, newNPC, 0, NPC.Position, NPC.Velocity, nil)
										NPC:Remove()
									end
								end
							end
						end
					end
					for _,entity in pairs(Isaac.GetRoomEntities()) do
						if entity:IsActiveEnemy() and entity:IsVulnerableEnemy() then
							local NPC = entity:ToNPC()
							if (NPC:IsBoss()) or (NPC.SpawnerEntity and NPC.SpawnerEntity:IsBoss()) then
								NPC:AddCharmed(EntityRef(entity), 10 * 30)
							else
								NPC:AddCharmed(EntityRef(entity), -1)
							end
						end
					end
					SFX:Play(SoundEffect.SOUND_HAPPY_RAINBOW)
					if can_add_wisp then
						------v0.1.0改动
						player:AddWisp(136, player.Position)	--标记魂火
						------
					end
				elseif magicID == 7 then
					data.PlayerData.HasBarrier = 0
					local tmp = player:GetEffects()
					if (tmp:GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_HOLY_MANTLE) == 0) then
					----二阶强化术----
						tmp:AddCollectibleEffect(CollectibleType.COLLECTIBLE_HOLY_MANTLE, true, 1 + math.floor(data.Magic[5].OrbsCount / 2))
						data.PlayerData.HasBarrier = data.PlayerData.HasBarrier + 1 + math.floor(data.Magic[5].OrbsCount / 2)
					else
						player:UseActiveItem(CollectibleType.COLLECTIBLE_BOOK_OF_SHADOWS, UseFlag.USE_NOANIM)
						tmp:AddCollectibleEffect(CollectibleType.COLLECTIBLE_HOLY_MANTLE, true, math.floor(data.Magic[5].OrbsCount / 2))
						data.PlayerData.HasBarrier = data.PlayerData.HasBarrier + math.floor(data.Magic[5].OrbsCount / 2)
					end
					if can_add_wisp then
						player:AddWisp(58, player.Position)		--护盾魂火
					end
				elseif magicID == MagicName.GRANDCROSS then
					local filter = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.GRANDCROSS_FILTER, 0, player.Position, Vector(0, 0), player):ToEffect()
					filter.LifeSpan = 3 * 60
					filter.Timeout = 3 * 60
					filter.DepthOffset = 0
					local room = Game():GetRoom()
					local aircraft = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.GRANDCROSS_AIRCRAFT, 0, room:GetCenterPos() + Vector(-1000, 0), Vector(15, 0), player):ToEffect()
					blueg_gcaircraft(aircraft)
					aircraft.DepthOffset = 999998
					aircraft.LifeSpan = 3 * 60
					aircraft.Timeout = 3 * 60
					aircraft.SpriteScale = Vector(2, 2)
					if can_add_wisp then
						player:AddWisp(40, player.Position)		--神风魂火
					end
				end
			elseif data.Magic[magicID].Type == MagicType.SPECIAL then
				if magicID == 5 then
					if data.Magic[5].OrbsCount == 0 and can_add_wisp then
						------v0.1.0改动
						player:AddWisp(720, player.Position)	--灰色魂火
						------
					end
					data.Magic[5].OrbsCount = data.Magic[5].OrbsCount + 1
					player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
					player:EvaluateItems()
				end
			end
		end

		function blueg_gcaircraft(aircraft)
			local aircrafts = {
				[1] = "Lighting",
				[2] = "Mosquito",
				[3] = "Shinden",
				[4] = "Ayako",
				[5] = "AyakoII",
				[6] = "AyakoIII",
				[7] = "V3rocket",
				[8] = "Gotha",
				[9] = "Blacknoise",
			}
			local aircraft_rand = math.random(1,#aircrafts)
			if aircraft_rand == 7 and math.random(1,100) <= 10 then
				aircraft_rand = 4
			end
			aircraft:GetSprite():Play(aircrafts[aircraft_rand])
		end

		local DEF_collision_DONE = false

		function tbom:blueg_effect_DEF_collision(player, other, boolean_low)
			local data = magic_data
			local tmp = player:GetEffects()
			if other:IsEnemy() and other.CollisionDamage > 0 and (not EntityRef(other).IsFriendly) and (not DEF_collision_DONE) then
				DEF_collision_DONE = true
				if data.PlayerData.HasBarrier > 0 and tmp:HasCollectibleEffect(CollectibleType.COLLECTIBLE_HOLY_MANTLE) then
					for _,entity in pairs(Isaac.GetRoomEntities()) do
						if entity:IsActiveEnemy() and entity:IsVulnerableEnemy() and (not EntityRef(other).IsFriendly) then
							entity:TakeDamage((4 + data.PlayerData.HasBarrier) * player.Damage, 0, EntityRef(player), 0)
						end
					end
					SFXManager():Play(SoundEffect.SOUND_DIVINE_INTERVENTION)
					Game():ShakeScreen(10)
					data.PlayerData.HasBarrier = math.max(0, data.PlayerData.HasBarrier - 1)
				end
				DEF_collision_DONE = false
			end
			return nil
		end
		tbom:AddCallback(ModCallbacks.MC_PRE_PLAYER_COLLISION, tbom.blueg_effect_DEF_collision, 0)

		function tbom:blueg_effect_SPC_update(familiar)
			local data = magic_data
			local player = familiar.Player
			if (familiar.OrbitLayer < 0) then
				familiar:AddToOrbit(240)
			end
            familiar.OrbitDistance = EntityFamiliar.GetOrbitDistance(1)
            familiar.OrbitSpeed = 0.06
			local parent = familiar.Parent or player
			familiar.Velocity = parent.Position + familiar:GetOrbitPosition(Vector.Zero) - familiar.Position

			if data.Magic[5].CD.Current ~= 0 then
				if data.Magic[5].CD.Current <= data.Magic[5].CD.STD / 2 then
					------v0.0.2新增------
					if familiar:Exists() then
						local poof = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01, 0, familiar.Position, Vector(0,0), nil):ToEffect()
						poof:GetSprite():Play("Poof_Small")
						poof:GetSprite().Color = Color(1,1,1,1,0.02,0.93,1)
					end
					----------------------
					familiar:Remove()
					data.Magic[5].OrbsCount = 0
				elseif data.Magic[5].CD.Current <= data.Magic[5].CD.STD * (0.5 + 0.1) then
					local sprite = familiar:GetSprite()
					if (not sprite:IsPlaying("Dying")) then
						sprite:Play("Dying")
					end
					sprite:SetFrame(math.floor(data.Magic[5].CD.Current % 16))
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_FAMILIAR_UPDATE, tbom.blueg_effect_SPC_update, modFamiliarVariant.LIGHT_ORB)

		function isInLaserSight(player, other)
			local sight_dir = Vector.FromAngle(player:GetSmoothBodyRotation()):Normalized()
			------v0.0.2新增------
			if (other.Position - player.Position):Length() > 500 then
				return false
			end
			----------------------
			------v0.0.3修复------
			local target_dir = (other.Position - player.Position):Normalized()
			local angle = math.deg(math.acos(sight_dir:Dot(target_dir)))
			if angle <= 15 and angle >= 0 then
				return true
			else
				return false
			end
			------
		end

		function tbom:blueg_effect_LOCKON(player)
			local SFX = SFXManager()
			local data = magic_data
			local magicID = data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]
			local current_magic = data.Magic[magicID]
			------v0.1.0新增
			local infMP_challenge = false
			if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER and magicID == 8 then
				infMP_challenge = true
			end
			------
			if current_magic and current_magic.Type == MagicType.LOCKON then
				------v0.1.0改动
				if magicID == 8 then
					data.PlayerData.LockonDMGMulti = current_magic.DMGMulti
				else
					data.PlayerData.LockonDMGMulti = current_magic.DMGMulti * (1 + 0.5 * data.Magic[5].OrbsCount)		------二阶强化术（暂未开放）------
				end
				------
				if current_magic.CD ~= 0 then
					if (not data.PlayerData.LaserSight or not data.PlayerData.LaserSight:Exists()) then
						data.PlayerData.LaserSight = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.LASERSIGHT, 0, player.Position, Vector(0,0), player):ToEffect()
						SFX:Play(SoundID.lasersight)
						data.PlayerData.LaserSight.Parent = player
						if current_magic.CostCP >= current_magic.TargetAmount then
							data.PlayerData.LaserSight:GetSprite().Color = Color(1 - (data.PlayerData.LockonCount / 5),(data.PlayerData.LockonCount / 5),0,0.3,0,0,0)
						else
							data.PlayerData.LaserSight:GetSprite().Color = Color(0,1,0,0.3,0,0,0)
						end
						data.PlayerData.LaserSight.SpriteScale = Vector(0.5, 1)
						data.PlayerData.LaserSight.Rotation = player:GetSmoothBodyRotation() - 90
						data.PlayerData.LaserSight.SpriteRotation = data.PlayerData.LaserSight.Rotation
						data.PlayerData.LaserSight.Position = player.Position
					end

					for i, entity in pairs(Isaac.GetRoomEntities()) do
						if entity:IsVulnerableEnemy() then
							if isInLaserSight(player, entity) then
								local entity_data = entity:GetData()
								local mark = nil
								if ((entity_data.MarksAmount == nil) or (entity.HitPoints >= entity_data.MarksAmount * player.Damage * (data.PlayerData.LockonDMGMulti)))	--敌人目前叠的标记数不足以杀死它
								and (current_magic.CostCP < current_magic.TargetAmount)		--标记数目未达到上限
								and (data.PlayerData.MadouRyoku >= current_magic.Cost)		--魔导力足够
								and (data.PlayerData.LockonCount == 0)						--每次标记的时间间隔（计数器）归零
								and (not EntityRef(entity).IsFriendly) then					--敌人未被永久魅惑
									if entity_data.MarksAmount == nil then
										entity_data.MarksAmount = 0
									end
									entity_data.MarksAmount = entity_data.MarksAmount + 1
									current_magic.CostCP = current_magic.CostCP + 1
									------v0.1.0新增
									if not infMP_challenge then
										data.PlayerData.MadouRyoku = data.PlayerData.MadouRyoku - current_magic.Cost
									end
									------
									table.insert(data.PlayerData.LockonTargetHeap, entity)

									local mark = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.LOCKONMARK, 0, entity.Position, Vector(0,0), entity):ToEffect()
									SFX:Play(SoundID.lockonmark)
									mark.Parent = entity
									mark.DepthOffset = 999999
									mark:FollowParent(mark.Parent)

									data.PlayerData.LockonCount = 5
								end
							end
						elseif (entity.Type == EntityType.ENTITY_EFFECT and entity.Variant == modEffectVariant.LOCKONMARK) then
							if entity.Parent == nil then
								entity:Remove()
								current_magic.CostCP = current_magic.CostCP - 1
							end
						end
					end

					if data.PlayerData.LockonCount > 0 then
						data.PlayerData.LockonCount = data.PlayerData.LockonCount - 1
					else
						data.PlayerData.LockonCount = 0
					end
				else
					for i = 1, current_magic.TargetAmount do
						local target = data.PlayerData.LockonTargetHeap[1]
						if target and target:Exists() then
							------v0.1.1改动------
							if magicID == 8 then
								local rocket = Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.ROCKET, 0, target.Position, Vector(0,0), player):ToEffect()
								rocket.LifeSpan = 2
								rocket.Timeout = 2
							elseif magicID == MagicName.DARKSLASH then
								local slash_dir = target.Position - player.Position
								local slash = player:FireTechLaser(player.Position, LaserOffset.LASER_TECH2_OFFSET, slash_dir:Normalized(), false, false, nil, current_magic.DMGMulti):ToLaser()
								slash.Parent = player
								--slash:SetTimeout(15)
								slash.Timeout = 15
								slash.TearFlags = player.TearFlags | TearFlags.TEAR_PIERCING | TearFlags.TEAR_SPIRAL
								--slash.DisableFollowParent = true
								--slash:AddTearFlags(TearFlags.TEAR_SPECTRAL)
								--slash:FollowParent()
								slash:SetColor(Color(0, 0, 0, 0.7, 0.4, 0, 0.82), 9999999, 99, false, false)
								slash:SetMaxDistance((target.Position - player.Position):Length())
								slash:GetData().darkslash_STA = player
								slash:GetData().darkslash_END = target
							end
							------
							if target and target:Exists() then
								local previous_data = target:GetData()
								if previous_data.MarksAmount then
									previous_data.MarksAmount = previous_data.MarksAmount - 1
								end
							end
							table.remove(data.PlayerData.LockonTargetHeap, 1)	--删除链表首节点（模拟）
						else
							table.remove(data.PlayerData.LockonTargetHeap, 1)
						end
					end
					for i, entity in pairs(Isaac.GetRoomEntities()) do
						if entity.Type == EntityType.ENTITY_EFFECT and entity.Variant == modEffectVariant.LOCKONMARK then
							entity:Remove()
						end
					end
					current_magic.CostCP = 0
					if data.PlayerData.LaserSight and data.PlayerData.LaserSight:Exists() then
						data.PlayerData.LaserSight:Remove()
						data.PlayerData.LaserSight = nil
					end

				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, tbom.blueg_effect_LOCKON)

		--[[function tbom:blueg_playerrender(player)		--测试专用
			local font = FontList[Options.Language] or FontList.en
			local data = magic_data
			local current_magic = data.Magic[data.PlayerData.CurrentMagic]

			local texts = {
				[1] = "Name: "..current_magic.Name.Light.zh,
				[2] = "CD: ",
				[3] = "Level: "..current_magic.Reberu,
			}
			if player:HasCollectible(ItemID.bluegrimoire) then
				if current_magic.Type == MagicType.AGGRESSIVE then
					texts[2] = "CD: "..current_magic.CD
				else
					texts[2] = "CD: "..math.floor(current_magic.CD.Current / 60)
				end

				local pos = Isaac.WorldToScreen(player.Position)
				for i=1, #texts do
					font:DrawStringUTF8(texts[i], pos.X - 200, pos.Y - 80 - 5 * #texts + i * 15, KColor(1,1,1,0.8), 400, true)
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_RENDER,tbom.blueg_playerrender)]]

		local blueg_flash = 0

		function tbom:blueg_render()
			local font = FontList[Options.Language] or FontList.en
			local num_font = Font()
			num_font:Load("font/pftempestasevencondensed.fnt")
			local data = magic_data
			------v0.1.0改动
			local magicID = data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]
			local current_magic = data.Magic[magicID] or data.Magic[1]
			------
			local magic_attribute = data.PlayerData.MagicAttribute

			local player = Game():GetPlayer(0)
			
			local MagicIcon = {}
			for _,i in pairs(data.PlayerData.UseableMagic) do
				MagicIcon[i] = {
					icon = Sprite(),
					shade = Sprite(),
				}
			end
			local icon_cursor = Sprite()

			if player:HasCollectible(ItemID.bluegrimoire) then
				if not Game():GetSeeds():HasSeedEffect(SeedEffect.SEED_NO_HUD) and Game():GetHUD():IsVisible() == true then
					local hudOffset = Options.HUDOffset
					local manaX = 50 + 20 * hudOffset
					local manaY = 33 + 12 * hudOffset
					local iconX = Isaac.GetScreenWidth() * 0.18
					local iconY = Isaac.GetScreenHeight() * 0.82
					local pos = Vector(iconX, iconY)
					local playerType = player:GetPlayerType()

					------v0.1.0改动
					local infMP_challenge = false
					if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER then
						infMP_challenge = true
					end
					if infMP_challenge then
						num_font:DrawString("INF/INF", manaX, manaY, KColor(1,1,1,0.65,0,0,0), 0, true)
					else
						num_font:DrawString(tostring(Fix_Round(data.PlayerData.MadouRyoku, 1)).."/"..tostring(Fix_Round(data.PlayerData.MadouJyougen, 1)), manaX, manaY, KColor(1,1,1,0.65,0,0,0), 0, true)
					end
					------
					local manaIcon = Sprite()
					manaIcon:Load("gfx/tbom/ui/hud_mana.anm2")
					manaIcon:Play("Idle")
					manaIcon.Color = Color(1,1,1,0.65,0,0,0)
					manaIcon:Render(Vector(manaX - 8, manaY + 8))

					if canUseVariousSpells(player) then
						local karaa = Color(1,1,1,0.8,0,0,0)
						local icon_distance = 18
						------v0.1.0改动（原magicID更名为ID）
						for i, ID in pairs(magic_data.PlayerData.UseableMagic) do
							local pos_arle = pos
							if i <= #(magic_data.PlayerData.UseableMagic) / 2 then
								pos_arle = Vector(iconX + icon_distance * (i - 1), iconY)
							else
								pos_arle = Vector(iconX + icon_distance * ((i - 1) % (#(magic_data.PlayerData.UseableMagic) / 2)), iconY + icon_distance)
							end
							magic_data.Magic[ID].IconPos = pos_arle
						end
						------
								------v0.1.0改动--------------
						local isAllowed_Icon = true

						for _,i in pairs(data.PlayerData.UseableMagic) do
							if data.Magic[i].Reberu > 0 then
								MagicIcon[i].icon:Load("gfx/tbom/ui/magic.anm2")
								MagicIcon[i].icon:Play("Icon")
								MagicIcon[i].icon:SetFrame(i)
								MagicIcon[i].icon.Color = karaa
								MagicIcon[i].icon:Render(data.Magic[i].IconPos)

								MagicIcon[i].shade:Load("gfx/tbom/ui/magic.anm2")
								MagicIcon[i].shade:Play("Shade")

								if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER and i ~= 8 then
									isAllowed_Icon = false
								else
									isAllowed_Icon = true
								end

								if data.Magic[i].Type == MagicType.AGGRESSIVE or data.Magic[i].Type == MagicType.LOCKON then
								--如果魔导力不够，则把shade的帧设为1（但是冷却时间要优先判断！）
									if (data.PlayerData.MadouRyoku >= data.Magic[i].Cost) and isAllowed_Icon then
										MagicIcon[i].shade:SetFrame(0)
									else
										MagicIcon[i].shade:SetFrame(1)
									end
								else
									MagicIcon[i].shade:SetFrame(math.ceil((data.Magic[i].CD.Current / data.Magic[i].CD.STD) * 33))
									if (data.Magic[i].CD.Current == 0 and data.PlayerData.MadouRyoku < data.Magic[i].Cost) or (not isAllowed_Icon) then
										MagicIcon[i].shade:SetFrame(1)
									end
								end
								------------------------------
								MagicIcon[i].shade.Color = karaa
								MagicIcon[i].shade:Render(data.Magic[i].IconPos)

								if data.Magic[i].Type ~= MagicType.DEFENSIVE then
									if data.Magic[i].Type == MagicType.LOCKON then
										--if i == 8 then
											num_font:DrawStringScaled(tostring(data.Magic[i].TargetAmount - data.Magic[i].CostCP), data.Magic[i].IconPos.X + 1.5, data.Magic[i].IconPos.Y - 2, 0.8 ,0.8, KColor(1,1,1,0.8,0,0,0), 0, true)
										--end
									elseif data.Magic[i].Type == MagicType.SPECIAL then
										if i == 5 then
											num_font:DrawStringScaled(tostring(data.Magic[i].Reberu - data.Magic[i].OrbsCount), data.Magic[i].IconPos.X + 1.5, data.Magic[i].IconPos.Y - 2, 0.8 ,0.8, KColor(1,1,1,0.8,0,0,0), 0, true)
										end
									else
										num_font:DrawStringScaled(tostring(data.Magic[i].Reberu), data.Magic[i].IconPos.X + 1.5, data.Magic[i].IconPos.Y - 2, 0.8 ,0.8, KColor(1,1,1,0.8,0,0,0), 0, true)
									end
								end
							end
						end

						icon_cursor:Load("gfx/tbom/ui/magic.anm2")
						icon_cursor:Play("Cursor")
						icon_cursor:SetFrame(0)
						local karaa_flash = KColor(1,1,1,0.8)
						if (current_magic.Type == MagicType.AGGRESSIVE or current_magic.Type == MagicType.LOCKON) and current_magic.CD == 1 then
							icon_cursor:SetFrame(1)
							karaa_flash = KColor(1 - math.abs(math.sin(blueg_flash * (math.pi / 60))),1,1 - math.abs(math.sin(blueg_flash * (math.pi / 60))),0.8)
							blueg_flash = (blueg_flash + 1) % 120
						end
						icon_cursor.Color = karaa
						icon_cursor:Render(current_magic.IconPos)

						------v0.1.0新增--------------
						local isAllowed_Text = true
						if Isaac.GetChallenge() == ChallengeID.CHALLENGE_METEOR_SHOWER then
							if magicID ~= 8 then
								isAllowed_Text = false
							end
						end
						------------------------------
						local isManaEnough = 0
						if data.PlayerData.MadouRyoku < current_magic.Cost then
							isManaEnough = 1
						end
						local IconPos_STD = data.Magic[data.PlayerData.UseableMagic[1]]
						if current_magic.Reberu > 0 then
							local magic_name = current_magic.Name[magic_attribute] or current_magic.Name["Light"]
							if (Options.Language == "zh") then
								font:DrawStringScaledUTF8((magic_name.zh or magic_name.zh), IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 24, 1, 1, karaa_flash, 10, true)
								------v0.1.0改动--------------
								if isAllowed_Text then
									if current_magic.Type == MagicType.AGGRESSIVE or current_magic.Type == MagicType.LOCKON then
										font:DrawStringScaledUTF8("消耗魔导力："..current_magic.CostDesc.zh, IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1, 1 - isManaEnough, 1 - isManaEnough, 0.8), 10, true)
									else
										if current_magic.CD.Current == 0 
										or (data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey] == 5 and current_magic.CD.Current > current_magic.CD.STD / 2) then
											font:DrawStringScaledUTF8("消耗魔导力："..current_magic.Cost, IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1, 1 - isManaEnough, 1 - isManaEnough, 0.8), 10, true)
										else
											font:DrawStringScaledUTF8("恢复中...", IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1,0,0,0.8), 10, true)
										end
									end
								else
									font:DrawStringScaledUTF8("本挑战不允许", IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1,0,0,0.8), 10, true)
								end
								------------------------------
							else
								font:DrawStringScaledUTF8((magic_name.en or magic_name.en), IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 24, 1, 1, karaa_flash, 10, true)
								------v0.1.0改动--------------
								if isAllowed_Text then
									if current_magic.Type == MagicType.AGGRESSIVE or current_magic.Type == MagicType.LOCKON then
									------v0.0.1改动------
										font:DrawStringScaledUTF8("MP cost: "..current_magic.CostDesc.en, IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1, 1 - isManaEnough, 1 - isManaEnough, 0.8), 10, true)
									------
									else
										if current_magic.CD.Current == 0 
										or (data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey] == 5 and current_magic.CD.Current > current_magic.CD.STD / 2) then
											------v0.0.1改动------
											font:DrawStringScaledUTF8("MP cost: "..current_magic.Cost, IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1, 1 - isManaEnough, 1 - isManaEnough, 0.8), 10, true)
											------
										else
											font:DrawStringScaledUTF8("Recharging...", IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1,0,0,0.8), 10, true)
										end
									end
								else
									font:DrawStringScaledUTF8("Not allowed in this challenge", IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 38, 0.75, 0.75, KColor(1,0,0,0.8), 10, true)
								end
								------------------------------
							end
						else
							font:DrawStringScaledUTF8("???", IconPos_STD.IconPos.X + 22, IconPos_STD.IconPos.Y + 24, 1, 1, KColor(1,1,1,0.8), 10, true)
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_RENDER,tbom.blueg_render)
		--tbom:AddPriorityCallback(ModCallbacks.MC_POST_RENDER, CallbackPriority.LATE, tbom.blueg_render)

		function tbom:blueg_darks_laser_update()
			local entities = Isaac.GetRoomEntities()
			for i = 1, #entities do
				if entities[i].Type == EntityType.ENTITY_LASER then
					local laser = entities[i]:ToLaser()
					local laser_data = entities[i]:GetData()
					if laser_data.darkslash_STA and laser_data.darkslash_END then
						local init = laser_data.darkslash_STA.Position
						local fin = laser_data.darkslash_END.Position
						laser.Position = init
						laser.Angle = (fin - init):GetAngleDegrees()
						
						laser:SetMaxDistance((init - fin):Length())
						--laser:AddTearFlags(TearFlags.TEAR_SPECTRAL | TearFlags.TEAR_PIERCING)
						--laser.GridHit = false
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_UPDATE, tbom.blueg_darks_laser_update)

		function tbom:blueg_grandc_filter_update(effect)
			local data = magic_data
			local current_magic = data.Magic[data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]] or data.Magic[1]
			local player = Game():GetPlayer(0)
			local room = Game():GetRoom()
			local sprite = effect:GetSprite()
			sprite:SetFrame(effect.Timeout % 4)

			effect.Position = player.Position
			effect.Velocity = player.Velocity
			effect:FollowParent(player)
			effect.Timeout = effect.Timeout - 1

			if effect.Timeout < 0 then
				effect:Remove()
			end
			if effect.Timeout % 6 == 0 then
				local missle = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.GRANDCROSS_MISSLE, 0, room:GetRandomPosition(40), Vector(0,0), player):ToEffect()
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE,tbom.blueg_grandc_filter_update,modEffectVariant.GRANDCROSS_FILTER)

		function tbom:blueg_grandc_missle_init(effect)
			local sprite = effect:GetSprite()
			effect.LifeSpan = 15
			effect.Timeout = 15
			effect.PositionOffset = effect.Timeout * Vector(-2000, 0)
			effect.SpriteScale = Vector(1.5, 0.5)
			effect.DepthOffset = 999980
			effect.CollisionDamage = 50
			sprite:Play("Pulse")
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_INIT, tbom.blueg_grandc_missle_init, modEffectVariant.GRANDCROSS_MISSLE)

		function tbom:blueg_grandc_missle_update(effect)
			effect.Timeout = effect.Timeout - 1
			effect.PositionOffset = effect.Timeout * Vector(-20, 0)
			if effect.Timeout < 0 then
				effect:Remove()
				Game():BombExplosionEffects(effect.Position, effect.CollisionDamage, TearFlags.TEAR_NORMAL, Color.Default, effect.SpawnerEntity, 1, true, false)
				Game():ShakeScreen(10)
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, tbom.blueg_grandc_missle_update, modEffectVariant.GRANDCROSS_MISSLE)

		function tbom:blueg_jugem_lasersight_render(effect, offset)
			local data = magic_data
			local current_magic = data.Magic[data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]] or data.Magic[1]
			local player = Game():GetPlayer(0)
			------v0.1.0修复
			if current_magic.Type == MagicType.LOCKON then
				if current_magic.CostCP >= current_magic.TargetAmount then
					effect:GetSprite().Color = Color(1 - (data.PlayerData.LockonCount / 5),(data.PlayerData.LockonCount / 5),0,0.3,0,0,0)
				else
					effect:GetSprite().Color = Color(0,1,0,0.3,0,0,0)
				end
				effect.SpriteScale = Vector(0.5, 1)
				effect.Rotation = player:GetSmoothBodyRotation() - 90
				effect.SpriteRotation = effect.Rotation
				effect.Position = player.Position
				effect.Velocity = player.Velocity
				effect:FollowParent(player)
			end
			------
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_RENDER,tbom.blueg_jugem_lasersight_render,modEffectVariant.LASERSIGHT)

		function tbom:blueg_magiccircle_render(effect, offset)
			local data = magic_data
			local current_magic = data.Magic[data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]] or data.Magic[1]
			local player = Game():GetPlayer(0)
			if effect and effect:Exists() then
				if data.PlayerData.UsingAggressiveMagic then
					local ATKmagicID = data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]
					if ATKmagicID == 1 then
						effect:SetColor(Color(1, 1, 1, 1, 0.3, 0, 0), -1, 1, false)
					elseif ATKmagicID == 2 then
						effect:SetColor(Color(0.518, 0.671, 0.976, 1, 0.14, 0.16, 0.18), -1, 1, false)
					elseif ATKmagicID == 3 then
						effect:SetColor(Color(1, 1, 0, 1, 0.3, 0.3, 0.3), -1, 1, false)
					end
					effect.SpriteScale = Vector(0.5, 0.5)
					effect.Position = player.Position
					effect.Velocity = player.Velocity
					effect:FollowParent(player)
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_RENDER,tbom.blueg_magiccircle_render,modEffectVariant.MAGIC_CIRCLE)
		

		local function blueg_getkey(amount)
			local key = {
				[1] = Input.IsButtonTriggered(Keyboard.KEY_1, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_1, 0),
				[2] = Input.IsButtonTriggered(Keyboard.KEY_2, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_2, 0),
				[3] = Input.IsButtonTriggered(Keyboard.KEY_3, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_3, 0),
				[4] = Input.IsButtonTriggered(Keyboard.KEY_4, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_4, 0),
				[5] = Input.IsButtonTriggered(Keyboard.KEY_5, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_5, 0),
				[6] = Input.IsButtonTriggered(Keyboard.KEY_6, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_6, 0),
				[7] = Input.IsButtonTriggered(Keyboard.KEY_7, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_7, 0),
				[8] = Input.IsButtonTriggered(Keyboard.KEY_8, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_8, 0),
				[9] = Input.IsButtonTriggered(Keyboard.KEY_9, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_9, 0),
				[10] = Input.IsButtonTriggered(Keyboard.KEY_0, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_DIVIDE, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_0, 0),
				[11] = Input.IsButtonTriggered(Keyboard.KEY_SEMICOLON, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_MULTIPLY, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_DECIMAL, 0),
				[12] = Input.IsButtonTriggered(Keyboard.KEY_EQUAL, 0) or Input.IsButtonTriggered(Keyboard.KEY_KP_SUBTRACT, 0),
			}
			for i = 1, #key do
				if key[i] and i <= amount then
					return i
				end
			end
			return nil
		end

		------v0.0.3改动------
		local defaultKeyConfig = {
			["Switch spell (Left) (Keyboard)"] = Keyboard.KEY_LEFT_ALT,
			["Switch spell (Right) (Keyboard)"] = Keyboard.KEY_RIGHT_CONTROL,
			["Switch spell (Left) (Controller)"] = 0,
			["Switch spell (Right) (Controller)"] = 1,
		}

		function blueg_GetKeyConfig()	--待修复
			local config = defaultKeyConfig
			if ModConfigMenu and ModConfigMenu.Config and ModConfigMenu.Config["The Binding of Madou"] then
				local category = ModConfigMenu.Config["The Binding of Madou"]
				config["Switch spell (Left) (Keyboard)"] = category["Switch spell (Left) (Keyboard)"]
				config["Switch spell (Right) (Keyboard)"] = category["Switch spell (Right) (Keyboard)"]
				config["Switch spell (Left) (Controller)"] = category["Switch spell (Left) (Controller)"]
				config["Switch spell (Right) (Controller)"] = category["Switch spell (Right) (Controller)"]
			end
			return config
		end

		function tbom:blueg_switch(player)
			local data = magic_data
			local current_magic = data.Magic[data.PlayerData.UseableMagic[data.PlayerData.CurrentMagicKey]]
			local controller_idx = player.ControllerIndex
			--local key_config = (ModConfigMenu and ModConfigMenu.Config) or defaultKeyConfig
			--print(ModConfigMenu.Config["Switch spell (Left) (Keyboard)"])
			local LeftTriggered = (blueg_GetKeyConfig() and (Input.IsButtonTriggered(blueg_GetKeyConfig()["Switch spell (Left) (Keyboard)"], controller_idx) or Input.IsButtonTriggered(blueg_GetKeyConfig()["Switch spell (Left) (Controller)"], controller_idx))) 
								or (Input.IsActionPressed(ButtonAction.ACTION_DROP, controller_idx) and Input.IsActionTriggered(ButtonAction.ACTION_SHOOTLEFT, controller_idx))
			local RightTriggered = (blueg_GetKeyConfig() and (Input.IsButtonTriggered(blueg_GetKeyConfig()["Switch spell (Right) (Keyboard)"], controller_idx) or Input.IsButtonTriggered(blueg_GetKeyConfig()["Switch spell (Right) (Controller)"], controller_idx)))
								or (Input.IsActionPressed(ButtonAction.ACTION_DROP, controller_idx) and Input.IsActionTriggered(ButtonAction.ACTION_SHOOTRIGHT, controller_idx))
			local amount = #(data.PlayerData.UseableMagic)
			local playerType = player:GetPlayerType()
			if player:HasCollectible(ItemID.bluegrimoire) and canUseVariousSpells(player) then
				if (not data.PlayerData.UsingAggressiveMagic) and amount > 1 then
					if LeftTriggered or RightTriggered then
						if RightTriggered then
							data.PlayerData.CurrentMagicKey = (data.PlayerData.CurrentMagicKey % amount) + 1
						else
							if data.PlayerData.CurrentMagicKey == 1 then
								data.PlayerData.CurrentMagicKey = amount
							else
								data.PlayerData.CurrentMagicKey = data.PlayerData.CurrentMagicKey - 1
							end
						end
					end
				end

				local key = blueg_getkey(amount)
				if key then
					if key == data.PlayerData.CurrentMagicKey then
						player:UseActiveItem(ItemID.bluegrimoire, UseFlag.USE_OWNED, ActiveSlot.SLOT_POCKET, 0)
					else
						if data.PlayerData.UsingAggressiveMagic and current_magic.Type == MagicType.AGGRESSIVE then
							player:UseActiveItem(ItemID.bluegrimoire, UseFlag.USE_OWNED, ActiveSlot.SLOT_POCKET, 0)
						end
						if not (data.PlayerData.UsingAggressiveMagic and current_magic.Type == MagicType.LOCKON) then
 							data.PlayerData.CurrentMagicKey = key
							if data.Magic[key].Type ~= MagicType.DEFENSIVE then
								player:UseActiveItem(ItemID.bluegrimoire, UseFlag.USE_OWNED, ActiveSlot.SLOT_POCKET, 0)
							end
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.blueg_switch)		--此处不用ModCallbacks.MC_POST_PLAYER_RENDER，防止Input.IsButtonTriggered()多次触发
		----------------------

		function tbom:blueg_spwanmana(pickup)
			local player = Game():GetPlayer(0)
			if player:HasCollectible(ItemID.bluegrimoire) then
				------v0.0.3
				if not (pickup:IsShopItem() or (pickup.Variant == PickupVariant.PICKUP_COIN and pickup.SubType == CoinSubType.COIN_GOLDEN)) then
				------
					local rand = pickup.DropSeed
					local playerType = player:GetPlayerType()
					if playerType == arlePlayerType or playerType == doppelPlayerType then
						rand = pickup.DropSeed % 10
					end
					if rand == 0 then
						pickup:Morph(EntityType.ENTITY_PICKUP, modPickupVariant.PICKUP_MANA, 0, false, true, true)
						return
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE,tbom.blueg_spwanmana,PickupVariant.PICKUP_HEART)
		tbom:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE,tbom.blueg_spwanmana,PickupVariant.PICKUP_COIN)
		tbom:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE,tbom.blueg_spwanmana,PickupVariant.PICKUP_BOMB)
		tbom:AddCallback(ModCallbacks.MC_POST_PICKUP_UPDATE,tbom.blueg_spwanmana,PickupVariant.PICKUP_KEY)

		function tbom:blueg_spwanmana_bonus(entity)
			if entity:IsActiveEnemy(true) and (not entity:HasEntityFlags(EntityFlag.FLAG_ICE_FROZEN)) then
				local npc = entity:ToNPC()
				local player = Game():GetPlayer(0)
				local playerType = player:GetPlayerType()
				local data = magic_data
				if player:HasCollectible(ItemID.bluegrimoire) then
					if (not canUseVariousSpells(player)) 
					or (canUseVariousSpells(player) and data.PlayerData.MadouRyoku <= data.PlayerData.MadouJyougen * 0.15) then	--如果角色不是是阿露露，或者阿露露的魔导力少于15%时，击杀怪物时有5%概率生成额外魔导力拾取物
						if npc.SpawnerType == 0 then
							local chance = math.random(1, 20)
							if chance == 1 then
								Isaac.Spawn(EntityType.ENTITY_PICKUP, modPickupVariant.PICKUP_MANA, 0, npc.Position, Vector.Zero, entity)
							end
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL,tbom.blueg_spwanmana_bonus,nil)

		function tbom:blueg_getmana(pickup, other, boolean_low)
			if (other.Type == 1 and other.Variant == 0) then
				local player = other:ToPlayer()
				local playerType = player:GetPlayerType()
				if magic_data.PlayerData.MadouRyoku < magic_data.PlayerData.MadouJyougen then
					if (not pickup.Touched) then
						PlayUniqueAnimation(pickup, "Collect")
						------v0.0.2改动------
						player:SetColor(Color(1,1,1,1,0.5,0.5,1), 6, -1, true)
						----------------------
						SFXManager():Play(SoundEffect.SOUND_BEEP)

						pickup:Remove()
						pickup.Touched = true
						if canUseVariousSpells(player) then
							magic_data.PlayerData.MadouRyoku = magic_data.PlayerData.MadouRyoku + 20
						else	--兼容其他角色
							magic_data.PlayerData.MadouRyoku = magic_data.PlayerData.MadouRyoku + 5
						end
						return true
					else
						return true
					end
				else
					return false
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION,tbom.blueg_getmana,modPickupVariant.PICKUP_MANA)

		function blueg_compatibility_OnUse(player, data, can_add_wisp)	--兼容其他角色
			local data = magic_data
			local magicID = math.random(1,3)
			------v0.0.3
			local magics = data.PlayerData.UseableVoidMagic
			magics[magicID] = magics[magicID] + 1
			------
			if magicID == 1 then
				if can_add_wisp then
					player:AddWisp(40, player.Position)			--神风魂火
				end
			elseif magicID == 2 then
				if can_add_wisp then
					player:AddWisp(171, player.Position)		--蜘蛛魂火
				end
			elseif magicID == 3 then
				if can_add_wisp then
					player:AddWisp(65536 + 4, player.Position)	--激光魂火
				end
			end

			local HUD = Game():GetHUD()
			local name = data.Magic[magicID].Name.Void or data.Magic[magicID].Name.Light
			if (Options.Language == "zh") then
				HUD:ShowItemText(name.zh, "")
			else
				HUD:ShowItemText(name.en, "")
			end

			player:AddCacheFlags(CacheFlag.CACHE_LUCK | CacheFlag.CACHE_FIREDELAY | CacheFlag.CACHE_DAMAGE | CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_TEARCOLOR)
			player:EvaluateItems()
		end
						
		------v0.0.3
		function tbom:blueg_compatibility_caflags(player, caflag)
			local data = magic_data
			local magics = data.PlayerData.UseableVoidMagic
			local tmp = player:GetEffects()
			local playerType = player:GetPlayerType()
			if (player:HasCollectible(ItemID.bluegrimoire) or data.PlayerData.VoidCount > 0) 
			and (not canUseVariousSpells(player)) then	--兼容其他角色和虚空
				if player:HasCollectible(CollectibleType.COLLECTIBLE_BOOK_OF_BELIAL_PASSIVE) and magics[1] + magics[2] + magics[3] > 0 then
					if caflag == CacheFlag.CACHE_DAMAGE then
						player.Damage = player.Damage * 1.3
					end
				end
				if magics[1] > 0 then
					if player:HasCollectible(CollectibleType.COLLECTIBLE_FIRE_MIND) or magics[1] > 1 then
						if caflag == CacheFlag.CACHE_LUCK then
							if player:HasCollectible(CollectibleType.COLLECTIBLE_FIRE_MIND) then
								player.Luck = player.Luck + 2 * magics[1]
							else
								player.Luck = player.Luck + 2 * (magics[1] - 1)
							end
						end
					end
					if not player:HasCollectible(CollectibleType.COLLECTIBLE_FIRE_MIND) then
						if caflag == CacheFlag.CACHE_TEARFLAG then
							player.TearFlags = player.TearFlags | TearFlags.TEAR_BURN
						end
						if caflag == CacheFlag.CACHE_TEARCOLOR then
							player.TearColor = Color(1, 1, 1, 1, 0.3, 0, 0)
						end
					end
				end
				if magics[2] > 0 then
					if caflag == CacheFlag.CACHE_TEARFLAG then
						player.TearFlags = player.TearFlags | TearFlags.TEAR_SLOW
					end
					if player:HasCollectible(CollectibleType.COLLECTIBLE_URANUS) or magics[2] > 1 then
						if caflag == CacheFlag.CACHE_FIREDELAY then
							if player:HasCollectible(CollectibleType.COLLECTIBLE_URANUS) then
								player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) + 1 * magics[2]) - 1)
							else
								player.MaxFireDelay = (30 / (30 / (player.MaxFireDelay + 1) + 1 * (magics[2] - 1)) - 1)
							end
						end
					end
					if not player:HasCollectible(CollectibleType.COLLECTIBLE_URANUS) then
						if caflag == CacheFlag.CACHE_TEARFLAG then
							player.TearFlags = player.TearFlags | TearFlags.TEAR_ICE
						end
					end
					if caflag == CacheFlag.CACHE_TEARCOLOR then
						player.TearColor = Color(0.518, 0.671, 0.976, 1, 0.35, 0.4, 0.45)
					end
				end
				if magics[3] > 0 then
					if (player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO) and player:HasCollectible(CollectibleType.COLLECTIBLE_JACOBS_LADDER)) or magics[3] > 1 then
						if caflag == CacheFlag.CACHE_DAMAGE then
							if player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO) and player:HasCollectible(CollectibleType.COLLECTIBLE_JACOBS_LADDER) then
								player.Damage = player.Damage + 2 * magics[3]
							else
								player.Damage = player.Damage + 2 * (magics[3] - 1)
							end
						end
					end
					if not (player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO) and player:HasCollectible(CollectibleType.COLLECTIBLE_JACOBS_LADDER)) then
						if caflag == CacheFlag.CACHE_TEARFLAG then
							player.TearFlags = player.TearFlags | TearFlags.TEAR_LASER | TearFlags.TEAR_JACOBS
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_EVALUATE_CACHE,tbom.blueg_compatibility_caflags)
		------

		function tbom:blueg_compatibility_award(RNG, spawn_pos)
			local data = magic_data
			local player = Isaac.GetPlayer(0)
			local playerType = player:GetPlayerType()
			------v0.0.3修复------
			if player:HasCollectible(ItemID.bluegrimoire) 
			and data.PlayerData.MadouRyoku < data.PlayerData.MadouJyougen 
			and (not canUseVariousSpells(player)) then	--兼容其他角色
				data.PlayerData.MadouRyoku = data.PlayerData.MadouRyoku + 1
				SFXManager():Play(SoundEffect.SOUND_BEEP)
			end
			----------------------
		end
		tbom:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD,tbom.blueg_compatibility_award)

		function tbom:blueg_compatibility_reset()
			local data = magic_data
			local magics = data.PlayerData.UseableVoidMagic
			local player = Isaac.GetPlayer(0)
			local playerType = player:GetPlayerType()
			------v0.0.3
			if (player:HasCollectible(ItemID.bluegrimoire) or data.PlayerData.VoidCount > 0) 
			and (not canUseVariousSpells(player)) then	--兼容其他角色和虚空
				for i = 1, 3 do
					magics[i] = 0
				end
				data.PlayerData.VoidCount = 0
			------
				player:AddCacheFlags(CacheFlag.CACHE_LUCK | CacheFlag.CACHE_FIREDELAY | CacheFlag.CACHE_DAMAGE | CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_TEARCOLOR)
				player:EvaluateItems()
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,tbom.blueg_compatibility_reset)

		function tbom:blueg_compatibility_update(player)
			local data = magic_data
			local playerType = player:GetPlayerType()
			if player:HasCollectible(ItemID.bluegrimoire) 
			and (not canUseVariousSpells(player)) then	--兼容其他角色
				if player:HasCollectible(CollectibleType.COLLECTIBLE_BATTERY) then
					data.PlayerData.MadouJyougen = 20
				else
					data.PlayerData.MadouJyougen = 10
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.blueg_compatibility_update)

	--绿色魔导书
		function tbom:greengrimoire(player)
			if player:HasCollectible(ItemID.greengrimoire) then
				local playerType = player:GetPlayerType()
				local HUD = Game():GetHUD()
				if canUseVariousSpells(player) then
					local ID = 8
					local attribute = "Light"
					if playerType == doppelPlayerType then
						ID = MagicName.GRANDCROSS
						attribute = "Dark"
					end
					local texts = {
						en = {
							Name = "Magic power up! ",
							Desc = 'You unlocked "'..magic_data.Magic[ID].Name[attribute].en..'" ! ',
						},
						zh = {
							Name = "魔法强化",
							Desc = "你解锁了“"..magic_data.Magic[ID].Name[attribute].zh.."”！",
						},
					}
					if magic_data.Magic[ID].Reberu == 0 then
						if (Options.Language == "zh") then
							HUD:ShowItemText(texts.zh.Name, texts.zh.Desc)
						else
							HUD:ShowItemText(texts.en.Name, texts.en.Desc)
						end
						magic_data.Magic[ID].Reberu = magic_data.Magic[ID].Reberu + 1
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.greengrimoire)

		function tbom:greeng_spawn(npc)
			local player = Isaac.GetPlayer(0)
			local playerType = player:GetPlayerType()
			if canUseVariousSpells(player) and (not player:HasCollectible(ItemID.greengrimoire)) then
				local game = Game()
				local level = game:GetLevel()
				local current_stage = level:GetAbsoluteStage()
				if current_stage > LevelStage.STAGE3_1 then
					local isHardMode = 0
					if game.Difficulty == Difficulty.DIFFICULTY_HARD or game.Difficulty == Difficulty.DIFFICULTY_GREEDIER then
						isHardMode = 20
					end
					local chance = math.random(1, 200 - isHardMode)
					if (not npc:IsBoss()) and chance == 1 then
						Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_COLLECTIBLE, ItemID.greengrimoire, npc.Position, Vector.Zero, nil)
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_NPC_DEATH,tbom.greeng_spawn,nil)

		local PuyoSkillCase = {
			SKILLCASE_WINCHESTER = 1,
			SKILLCASE_KNIFE = 2,
			SKILLCASE_DARTS = 3,
			SKILLCASE_BOOMERANG = 4,
			SKILLCASE_DYNAMITE = 5,
			SKILLCASE_SHOT_GUN = 6,
			SKILLCASE_DOUBLE_RIFLE = 7,
			SKILLCASE_DOUBLE_PISTOL = 8,
			SKILLCASE_MACHINE_GUN = 9,
			SKILLCASE_RIFLE = 10,
			SKILLCASE_ALT_RIFLE = 11,
			SKILLCASE_ALT_BOOMERANG = 12,
			SKILLCASE_ALT_FIRE_BALL = 13,
			SKILLCASE_ALT_DARTS = 14,
			SKILLCASE_ALT_BOMB_GUN = 15,
			SKILLCASE_ALT_MACHINE_GUN = 16,
		}

		function tbom:puyo_init(npc)
			if isInTable(npc.Variant, PuyoVariant) then
				local data = npc:GetData()
				local stage = Game():GetLevel():GetStage()
				data.FirePoint = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.PUYO_FIRE_POINT, 0, npc.Position, Vector(0,0), npc):ToEffect()
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_NPC_INIT, tbom.puyo_init, modEntityType.PUYO)

		function tbom:puyo_orig_projectile_remove(npc)
			local data = npc:GetData()
			local fire_point = data.FirePoint
			local entities = Isaac.GetRoomEntities()
			for i, entity in pairs(entities) do
				if entity.Type == EntityType.ENTITY_PROJECTILE then
					if entity.SpawnerType == npc.Type and isInTable(entity.SpawnerVariant, PuyoVariant) then
						entity:Remove()
					end
				end
			end
		end
		tbom:AddPriorityCallback(ModCallbacks.MC_NPC_UPDATE, CallbackPriority.EARLY, tbom.puyo_orig_projectile_remove, modEntityType.PUYO)

		--function tbom:puyo_projectile_flags(projectile)
		--	if projectile.SpawnerType == fire_point.Type and projectile.SpawnerVariant == fire_point.Variant then
		--		if npc:HasEntityFlags(EntityFlag.FLAG_SLOW) then
		--			projectile:AddProjectileFlags(ProjectileFlags.SLOWED)
		--		end
		--	end
		--end
		--tbom:AddCallback(ModCallbacks.MC_POST_PROJECTILE_INIT, tbom.puyo_projectile_flags, nil)

		function GetNearestPlayer(other)
			local player0 = Isaac.GetPlayer(0)
			local dis0 = (player0.Position - other.Position):Length()
			for p = 1, Game():GetNumPlayers() - 1 do
				local player = Isaac.GetPlayer(p)
				local dis = (player.Position - other.Position):Length()
				if dis < dis0 then
					dis0 = dis
					player0 = player
				end
			end
			return player0
		end

		function GetNearestPlayerDistance(other)
			local player0 = Isaac.GetPlayer(0)
			local dis0 = (player0.Position - other.Position):Length()
			for p = 1, Game():GetNumPlayers() - 1 do
				local player = Isaac.GetPlayer(p)
				local dis = (player.Position - other.Position):Length()
				if dis < dis0 then
					dis0 = dis
				end
			end
			return dis0
		end

		function puyo_shoot(npc, projectile_pos, projectile_dir)
			local data = npc:GetData()
			local fire_point = data.FirePoint
			local projectile = Isaac.Spawn(EntityType.ENTITY_PROJECTILE, 0, 0, projectile_pos, projectile_dir, fire_point):ToProjectile()
			if npc:HasEntityFlags(EntityFlag.FLAG_SLOW) then
				projectile:AddProjectileFlags(ProjectileFlags.SLOWED)
			end
			return projectile
		end

		function puyo_switch_skill(stage)
			local game = Game()
			local skill_case = 0
			if game.Difficulty == Difficulty.DIFFICULTY_NORMAL then
				skill_case = math.min(math.ceil(stage / 2), 6)
				skill_case = skill_case + 10
			elseif game.Difficulty == Difficulty.DIFFICULTY_HARD then
				if stage == LevelStage.STAGE5 or stage == LevelStage.STAGE4_3 then
					skill_case = PuyoSkillCase.SKILLCASE_MACHINE_GUN
				elseif stage >= LevelStage.STAGE6 then
					skill_case = PuyoSkillCase.SKILLCASE_RIFLE
				else
					skill_case = stage
				end
			elseif game.Difficulty == Difficulty.DIFFICULTY_GREED then
				skill_case = math.min(stage, 6)
				skill_case = skill_case + 10
			else
				if stage == LevelStage.STAGE1_GREED then
					skill_case = PuyoSkillCase.SKILLCASE_WINCHESTER
				elseif stage == LevelStage.STAGE2_GREED then
					skill_case = PuyoSkillCase.SKILLCASE_BOOMERANG
				elseif stage == LevelStage.STAGE3_GREED then
					skill_case = PuyoSkillCase.SKILLCASE_SHOT_GUN
				elseif stage == LevelStage.STAGE4_GREED then
					skill_case = PuyoSkillCase.SKILLCASE_DARTS
				elseif stage == LevelStage.STAGE5_GREED then
					skill_case = PuyoSkillCase.SKILLCASE_MACHINE_GUN
				else 
					skill_case = PuyoSkillCase.SKILLCASE_RIFLE
				end
			end
			return skill_case
		end

		function tbom:puyo_main(npc)
			if isInTable(npc.Variant, PuyoVariant) then
				local game = Game()
				local data = npc:GetData()
				local sprite = npc:GetSprite()
				local player = GetNearestPlayer(npc)
				if data.SkillTime == nil then
					data.SkillTime = 0
				end
				if data.ShootSpeed == nil then
					data.ShootSpeed = 10
				end
				if data.FireDealy == nil then
					data.FireDealy = 6
				end
				--注意：有些噗哟免疫火焰或冰冻。
				local skill_case = puyo_switch_skill(game:GetLevel():GetStage())
				local projectile_pos = npc.Position
				local projectile_dir = (player.Position - npc.Position):Normalized()
				if sprite:IsEventTriggered("Shoot") then
					if skill_case == PuyoSkillCase.SKILLCASE_WINCHESTER then
						data.FireDealy = 6
						data.SkillTime = data.FireDealy * 4
						data.ShootSpeed = 12
					elseif skill_case == PuyoSkillCase.SKILLCASE_KNIFE then
						data.ShootSpeed = 16
						for i = 1, 2 do
							local sign = 1 - (i - 1) * 2
							puyo_shoot(npc, projectile_pos + Vector(-10 * sign, 0), projectile_dir * data.ShootSpeed)
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_DARTS then
						data.FireDealy = 6
						data.SkillTime = data.FireDealy * 2
						data.ShootSpeed = 18
					elseif skill_case == PuyoSkillCase.SKILLCASE_BOOMERANG then
						data.FireDealy = 20
						data.SkillTime = data.FireDealy * 2
						data.ShootSpeed = 10
					elseif skill_case == PuyoSkillCase.SKILLCASE_DYNAMITE then
						data.FireDealy = 40
						data.SkillTime = data.FireDealy * 2
						data.ShootSpeed = 10
					elseif skill_case == PuyoSkillCase.SKILLCASE_SHOT_GUN then
						data.ShootSpeed = 14
						for i = 1, 3 do
							puyo_shoot(npc, projectile_pos, projectile_dir:Rotated(15 - 15 * (i - 1)) * data.ShootSpeed)
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_DOUBLE_RIFLE then
						data.FireDealy = 10
						data.SkillTime = data.FireDealy * 3
						data.ShootSpeed = 12
					elseif skill_case == PuyoSkillCase.SKILLCASE_DOUBLE_PISTOL then
						data.ShootSpeed = 12
						for i = 1, 2 do
							local sign = 1 - (i - 1) * 2
							local projectile = puyo_shoot(npc, projectile_pos + Vector(-10 * sign, 0):Rotated(projectile_dir:GetAngleDegrees() - 90), projectile_dir:Rotated(sign) * data.ShootSpeed)
							projectile.FallingSpeed = 0
							projectile.FallingAccel = -0.02
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_MACHINE_GUN then
						data.ShootSpeed = 16
						for i = 1, 2 do
							local sign = 1 - (i - 1) * 2
							local projectile = puyo_shoot(npc, projectile_pos + Vector(-10 * sign, 0):Rotated(projectile_dir:GetAngleDegrees() - 90), projectile_dir:Rotated(sign * 5) * data.ShootSpeed)
							projectile.FallingSpeed = 0
							projectile.FallingAccel = -0.02
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_RIFLE then
						data.ShootSpeed = 14
						for i = 1, 5 do
							local projectile_dir_fixed = projectile_dir + Vector(-0.577, 0) + Vector(0.577 / 2, 0) * (i - 1)
							if math.abs(projectile_dir:GetAngleDegrees()) < 45 or math.abs(projectile_dir:GetAngleDegrees()) > 135 then
								projectile_dir_fixed = projectile_dir + Vector(0, -0.577) + Vector(0, 0.577 / 2) * (i - 1)
							end
							local projectile = puyo_shoot(npc, projectile_pos, projectile_dir_fixed * data.ShootSpeed)
							projectile.FallingSpeed = 0
							projectile.FallingAccel = -0.02
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_RIFLE then
						data.FireDealy = 6
						data.SkillTime = data.FireDealy * 4
						data.ShootSpeed = 10
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_BOOMERANG then
						data.ShootSpeed = 14
						for i = 1, 2 do
							local projectile = puyo_shoot(npc, projectile_pos, projectile_dir:Rotated(30 - 60 * (i - 1)) * data.ShootSpeed)
							projectile:AddProjectileFlags(ProjectileFlags.SMART | ProjectileFlags.GHOST | ProjectileFlags.SHIELDED)
							projectile.FallingSpeed = 0
							projectile.FallingAccel = -0.05
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_FIRE_BALL then
						data.ShootSpeed = 14
						if math.random(1,2) == 1 then
							for i = 1, 3 do
								puyo_shoot(npc, projectile_pos, projectile_dir:Rotated(30 - 30 * (i - 1)) * data.ShootSpeed)
							end
						else
							for i = 1, 5 do
								puyo_shoot(npc, projectile_pos, projectile_dir:Rotated(60 - 30 * (i - 1)) * data.ShootSpeed)
							end
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_DARTS then
						data.ShootSpeed = 12
						local projectile = puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed)
						projectile:AddProjectileFlags(ProjectileFlags.BURST)
						projectile.FallingAccel = 0.1
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_BOMB_GUN then
						local projectile = puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed * 1.6)
						projectile:AddProjectileFlags(ProjectileFlags.EXPLODE | ProjectileFlags.ACID_GREEN)
						projectile.FallingAccel = 0.1
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_MACHINE_GUN then
						data.ShootSpeed = 12
						for i = 1, 3 do
							puyo_shoot(npc, projectile_pos, projectile_dir:Rotated(15 - 15 * (i - 1)) * data.ShootSpeed)
						end
					end
				end
				if data.SkillTime > 0 then
					if data.SkillTime % data.FireDealy == 0 then
						if skill_case == PuyoSkillCase.SKILLCASE_WINCHESTER then
							puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed)
						elseif skill_case == PuyoSkillCase.SKILLCASE_DARTS then
							puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed)
						elseif skill_case == PuyoSkillCase.SKILLCASE_BOOMERANG then
							for i = 1, 2 do
								local projectile = puyo_shoot(npc, projectile_pos, projectile_dir:Rotated(30 - 60 * (i - 1)) * data.ShootSpeed)
								projectile:AddProjectileFlags(ProjectileFlags.SMART | ProjectileFlags.GHOST | ProjectileFlags.SHIELDED)
								projectile.FallingSpeed = 0
								projectile.FallingAccel = -0.05
							end
						elseif skill_case == PuyoSkillCase.SKILLCASE_DYNAMITE then
							if data.SkillTime == data.FireDealy * 2 then
								puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed * 1.8):AddProjectileFlags(ProjectileFlags.BLUE_FIRE_SPAWN)
							else
								local projectile = puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed * 0.8)
								projectile:AddProjectileFlags(ProjectileFlags.EXPLODE | ProjectileFlags.ACID_GREEN)
								projectile.FallingSpeed = -13
								projectile.FallingAccel = 0.6
							end
						elseif skill_case == PuyoSkillCase.SKILLCASE_DOUBLE_RIFLE then
							for i = 1, 2 do
								local sign = 1 - (i - 1) * 2
								local projectile = puyo_shoot(npc, projectile_pos + Vector(-10 * sign, 0):Rotated(projectile_dir:GetAngleDegrees() - 90), projectile_dir:Rotated(sign * 10 * (3 - (data.SkillTime / data.FireDealy))) * data.ShootSpeed)
								projectile.FallingSpeed = 0
								projectile.FallingAccel = -0.02
							end
						elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_RIFLE then
							puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed)
						end
					end
					data.SkillTime = data.SkillTime - 1
				end
				local max_dis2player = 300
				if GetNearestPlayerDistance(npc) <= max_dis2player then
					if skill_case == PuyoSkillCase.SKILLCASE_DOUBLE_PISTOL then
						data.FireDealy = 10
						data.ShootSpeed = 12
						if npc.FrameCount % data.FireDealy == 0 then
							for i = 1, 2 do
								local sign = 1 - (i - 1) * 2
								local projectile = puyo_shoot(npc, projectile_pos + Vector(-10 * sign, 0):Rotated(projectile_dir:GetAngleDegrees() - 90), projectile_dir:Rotated(sign * 10 * ((npc.FrameCount % (data.FireDealy * 3)) / data.FireDealy)) * data.ShootSpeed)
								projectile.FallingSpeed = 0
								projectile.FallingAccel = -0.02
							end
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_MACHINE_GUN then
						data.FireDealy = 10
						data.ShootSpeed = 14
						if npc.FrameCount % data.FireDealy == 0 then
							for i = 1, 2 do
								local sign = 1 - (i - 1) * 2
								local projectile = puyo_shoot(npc, projectile_pos + Vector(-10 * sign, 0):Rotated(projectile_dir:GetAngleDegrees() - 90), projectile_dir:Rotated(sign * 5) * data.ShootSpeed)
								projectile.FallingSpeed = 0
								projectile.FallingAccel = -0.02
							end
						end
					elseif skill_case == PuyoSkillCase.SKILLCASE_ALT_MACHINE_GUN then
						data.FireDealy = 8
						data.ShootSpeed = 12
						if npc.FrameCount % data.FireDealy == 0 then
							puyo_shoot(npc, projectile_pos, projectile_dir * data.ShootSpeed)
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_NPC_UPDATE, tbom.puyo_main, modEntityType.PUYO)

		function puyo_isLinked(a, b)
			local max_distance = 40
			return (a.Position - b.Position):Length() <= max_distance
		end

		function puyo_owanimo(npc)
			local effect = PlayUniqueAnimation(npc, "Owanimo")
			local effect_data = effect:GetData()
			effect_data.PuyoOwanimo = true
			effect_data.PuyoVariant = npc.Variant
			SFXManager():Play(SoundID.puyoowanimo)
		end

		function tbom:puyo_brust(effect)
			local data = effect:GetData()
			if data.PuyoOwanimo and data.PuyoVariant then
				local effect_sprite = effect:GetSprite()
				if effect_sprite:IsEventTriggered("Burst") then
					local PuyoVariant2Gel = {
						[PuyoVariant.GREEN_PUYO] = GelSubType.GEL_GREEN,
					}
					local subtype = PuyoVariant2Gel[data.PuyoVariant] or GelSubType.GEL_GREEN
					Isaac.Spawn(EntityType.ENTITY_PICKUP, modPickupVariant.PICKUP_GEL, subtype, effect.Position, Vector.Zero, effect)
					for i = 1, 8 do
						local dis = Vector(5,0)
						local gibs = Isaac.Spawn(EntityType.ENTITY_EFFECT, modEffectVariant.PUYO_GIBS, 0, effect.Position, dis:Rotated(45 * i), effect):ToEffect()
						local PuyoVariant2Name = {
							[PuyoVariant.GREEN_PUYO] = "Green",
						}
						local gibs_anim_name = PuyoVariant2Name[data.PuyoVariant] or "Green"
						gibs:GetSprite():Play(gibs_anim_name)
					end
					SFXManager():Play(SoundID.puyobrust)
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_EFFECT_UPDATE, tbom.puyo_brust, modEffectVariant.BLANK_ANIM)

		function tbom:puyo_build()
			--第一步：构造数组
			local PuyoArrays = {
				Green = {},
				Blue = {},
				Yellow = {},
				Red = {},
				Purple = {},
				Golden = {},
			}
			local entities = Isaac.GetRoomEntities()
			for i, entity in pairs(entities) do
				if entity.Type == modEntityType.PUYO then
					if entity.Variant == PuyoVariant.GREEN_PUYO then
						table.insert(PuyoArrays.Green, entity)
					end
				end
			end
			--第二步：遍历各个数组，构造相容类
			for id, array in pairs(PuyoArrays) do
				if #(array) >= 4 then
					local LinkedPuyoHeap = {}
					for i = 2, #array do
						for j = 1, (i - 1) do
							if puyo_isLinked(array[i], array[j]) then
								if #LinkedPuyoHeap == 0 then
									table.insert(LinkedPuyoHeap, {i,j})
								else
									for k = 1, #LinkedPuyoHeap do
										local isNewPair = true
										if isInTable(i, LinkedPuyoHeap[k]) then
											isNewPair = false
											if not isInTable(j, LinkedPuyoHeap[k]) then
												table.insert(LinkedPuyoHeap[k],j)
											end
										elseif isInTable(j, LinkedPuyoHeap[k]) then
											isNewPair = false
											table.insert(LinkedPuyoHeap[k],i)
										end
										if isNewPair then
											table.insert(LinkedPuyoHeap,{i,j})
										end
									end
								end
							end
						end
					end
					--第三步：对符合要求的相容类内部元素触发“消除”函数
					for k = 1, #LinkedPuyoHeap do
						if #(LinkedPuyoHeap[k]) >= 4 then
							for m, n in ipairs(LinkedPuyoHeap[k]) do
								puyo_owanimo(array[n])
								array[n]:Remove()
								if m <= Game():GetNumPlayers() then
									local player = Isaac.GetPlayer(m - 1)
									if player:HasCollectible(ItemID.bluegrimoire) then
										Isaac.Spawn(EntityType.ENTITY_PICKUP, modPickupVariant.PICKUP_MANA, 0, (array[n]).Position, Vector.Zero, array[n])
									end
									if canGetEXP(player) then
										Character_EXPSpawn(player, (array[n]).Position, 10)
									end
								end
							end
						end
					end
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_UPDATE, tbom.puyo_build)

		--function tbom:puyo_gibs_init(effect)
		--	local data = effect:GetData()
		--	local sprite = effect:GetSprite()
		--end
		--tbom:AddPriorityCallback(ModCallbacks.MC_POST_EFFECT_INIT, CallbackPriority.LATE, tbom.Character_EXPInit, modEffectVariant.PUYO_GIBS)

		function tbom:puyo_spawngel(entity)
			if isInTable(entity.Variant, PuyoVariant) then
				local PuyoVariant2Gel = {
					[PuyoVariant.GREEN_PUYO] = GelSubType.GEL_GREEN,
				}
				local subtype = PuyoVariant2Gel[entity.Variant] or GelSubType.GEL_GREEN
				Isaac.Spawn(EntityType.ENTITY_PICKUP, modPickupVariant.PICKUP_GEL, subtype, entity.Position, Vector.Zero, entity)
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, tbom.puyo_spawngel, modEntityType.PUYO)

		function tbom:puyo_getgel(pickup, other, boolean_low)
			if (other.Type == 1 and other.Variant == 0) then
				local player = other:ToPlayer()
				--local playerType = player:GetPlayerType()
				if (not pickup.Touched) then
					PlayUniqueAnimation(pickup, "Collect")
					SFXManager():Play(SoundID.gelget)

					pickup:Remove()
					pickup.Touched = true
					return true
				else
					return true
				end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_PRE_PICKUP_COLLISION, tbom.puyo_getgel, modPickupVariant.PICKUP_GEL)

	--翻译
		Translation = {
			zh = {
				[CollectibleType.COLLECTIBLE_BIRTHRIGHT] = {
					[arlePlayerType] = {Name = "长子名分",Desc = "速攻考试",},
					[doppelPlayerType] = {Name = "长子名分",Desc = "不死之身",},
				},
				[ItemID.bluegrimoire] = {Name = "蓝色魔导书",Desc = "开始学习魔法吧！",},
				[ItemID.greengrimoire] = {Name = "绿色魔导书",Desc = "魔法强化！",},
			},
			en = {
				--Coming soon...
			},
		}

		local fixedItem = {
			--Coming soon...
		}

		function tbom:checkqueueditem(player)
			--local player = Game():GetPlayer(0)
			if player:IsItemQueueEmpty() then	--检查角色是否捡起了某拾取物；只对道具和饰品有效
				translated = false
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.checkqueueditem)

		function tbom:itemtranslation(player)
			--local player = Game():GetPlayer(0)
			local playerType = player:GetPlayerType()
			local HUD = Game():GetHUD()
			if (Options.Language == "zh") then
				if player:IsItemQueueEmpty() == false then
					local ID = player.QueuedItem.Item.ID
					if player.QueuedItem.Item:IsCollectible() 
					and (isInTable(ID, ItemID) or ID == CollectibleType.COLLECTIBLE_BIRTHRIGHT) then
						if not translated then
							if ID == CollectibleType.COLLECTIBLE_BIRTHRIGHT then
								if Translation.zh[ID][playerType] then
									HUD:ShowItemText(Translation.zh[ID][playerType].Name, Translation.zh[ID][playerType].Desc)
								end
							else
								HUD:ShowItemText(Translation.zh[ID].Name, Translation.zh[ID].Desc)
							end
						end
						translated = true
					end
				end
			--else
				--if player:IsItemQueueEmpty() == false then
					--local ID = player.QueuedItem.Item.ID
					--if player.QueuedItem.Item:IsCollectible() and isInTable(ID, fixedItem) then
						--if not translated then
							--HUD:ShowItemText(Translation.en[ID].Name, Translation.en[ID].Desc)
						--end
						--translated = true
					--end
				--end
			end
		end
		tbom:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,tbom.itemtranslation)

	------v0.0.2新增------
	--存档与读档
		local json = require("json")
		--//
		function GetDefaultArleData()
			return arleData_DEFAULT
		end

		function GetDefaultMagicData()
			return magic_data_DEFAULT
		end

		function tbom:SaveStaticData()
			local StaticData = {
				arleData = GetArleData(),
				magic_data = GetMagicData(),
			}
			tbom:SaveData(json.encode(StaticData))
		end
		--tbom:AddCallback(ModCallbacks.MC_PRE_GAME_EXIT, tbom.SaveStaticData)
		--tbom:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, tbom.SaveStaticData)

		function tbom:LoadStaticData(boolean_isContinued)
			if boolean_isContinued and tbom:HasData() then
				local StaticData = json.decode(tbom:LoadData())
				if StaticData then
					if StaticData.arleData then
						arleData = StaticData.arleData
					end
					if StaticData.magic_data then
						magic_data = StaticData.magic_data
					end
				end
			end
		end
		--tbom:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, tbom.LoadStaticData)
	----------------------
		--//

	--EID支持
		if EID then
			------v0.0.1改动------
			include("descriptions/main")
		end

	--ModConfigMenu支持
		if ModConfigMenu then
			local categoryName = "The Binding of Madou"
			ModConfigMenu.SimpleAddSetting(ModConfigMenu.OptionType.KEYBIND_KEYBOARD, categoryName, nil, "Switch spell (Left) (Keyboard)",
											nil, nil, nil, Keyboard.KEY_LEFT_ALT, 
											"Switch spell (Left)", nil, true, "Key to switch among Arle's spells")
			ModConfigMenu.SimpleAddSetting(ModConfigMenu.OptionType.KEYBIND_KEYBOARD, categoryName, nil, "Switch spell (Right) (Keyboard)", 
											nil, nil, nil, Keyboard.KEY_RIGHT_CONTROL, 
											"Switch spell (Right)", nil, true, "Key to switch among Arle's spells")
			ModConfigMenu.SimpleAddSetting(ModConfigMenu.OptionType.KEYBIND_CONTROLLER, categoryName, nil, "Switch spell (Left) (Controller)", 
											nil, nil, nil, 0, 
											"Switch spell (Left)", nil, true, "Key to switch among Arle's spells")
			ModConfigMenu.SimpleAddSetting(ModConfigMenu.OptionType.KEYBIND_CONTROLLER, categoryName, nil, "Switch spell (Right) (Controller)",
											nil, nil, nil, 1, 
											"Switch spell (Right)", nil, true, "Key to switch among Arle's spells")
		end

	do
		print("The Binding of Madou v0.1.0 loaded.")
	end
	do
		print("Developer only!")
	end

